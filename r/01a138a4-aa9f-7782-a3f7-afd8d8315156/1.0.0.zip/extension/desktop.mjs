var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// ../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/utils/utf8.cjs
var require_utf8 = __commonJS({
  "../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/utils/utf8.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.utf8Count = utf8Count;
    exports.utf8EncodeJs = utf8EncodeJs;
    exports.utf8EncodeTE = utf8EncodeTE;
    exports.utf8Encode = utf8Encode;
    exports.utf8DecodeJs = utf8DecodeJs;
    exports.utf8DecodeTD = utf8DecodeTD;
    exports.utf8Decode = utf8Decode;
    function utf8Count(str) {
      const strLength = str.length;
      let byteLength = 0;
      let pos = 0;
      while (pos < strLength) {
        let value = str.charCodeAt(pos++);
        if ((value & 4294967168) === 0) {
          byteLength++;
          continue;
        } else if ((value & 4294965248) === 0) {
          byteLength += 2;
        } else {
          if (value >= 55296 && value <= 56319) {
            if (pos < strLength) {
              const extra = str.charCodeAt(pos);
              if ((extra & 64512) === 56320) {
                ++pos;
                value = ((value & 1023) << 10) + (extra & 1023) + 65536;
              }
            }
          }
          if ((value & 4294901760) === 0) {
            byteLength += 3;
          } else {
            byteLength += 4;
          }
        }
      }
      return byteLength;
    }
    function utf8EncodeJs(str, output, outputOffset) {
      const strLength = str.length;
      let offset = outputOffset;
      let pos = 0;
      while (pos < strLength) {
        let value = str.charCodeAt(pos++);
        if ((value & 4294967168) === 0) {
          output[offset++] = value;
          continue;
        } else if ((value & 4294965248) === 0) {
          output[offset++] = value >> 6 & 31 | 192;
        } else {
          if (value >= 55296 && value <= 56319) {
            if (pos < strLength) {
              const extra = str.charCodeAt(pos);
              if ((extra & 64512) === 56320) {
                ++pos;
                value = ((value & 1023) << 10) + (extra & 1023) + 65536;
              }
            }
          }
          if ((value & 4294901760) === 0) {
            output[offset++] = value >> 12 & 15 | 224;
            output[offset++] = value >> 6 & 63 | 128;
          } else {
            output[offset++] = value >> 18 & 7 | 240;
            output[offset++] = value >> 12 & 63 | 128;
            output[offset++] = value >> 6 & 63 | 128;
          }
        }
        output[offset++] = value & 63 | 128;
      }
    }
    var sharedTextEncoder = new TextEncoder();
    var TEXT_ENCODER_THRESHOLD = 50;
    function utf8EncodeTE(str, output, outputOffset) {
      sharedTextEncoder.encodeInto(str, output.subarray(outputOffset));
    }
    function utf8Encode(str, output, outputOffset) {
      if (str.length > TEXT_ENCODER_THRESHOLD) {
        utf8EncodeTE(str, output, outputOffset);
      } else {
        utf8EncodeJs(str, output, outputOffset);
      }
    }
    var CHUNK_SIZE = 4096;
    function utf8DecodeJs(bytes, inputOffset, byteLength) {
      let offset = inputOffset;
      const end = offset + byteLength;
      const units = [];
      let result = "";
      while (offset < end) {
        const byte1 = bytes[offset++];
        if ((byte1 & 128) === 0) {
          units.push(byte1);
        } else if ((byte1 & 224) === 192) {
          const byte2 = bytes[offset++] & 63;
          units.push((byte1 & 31) << 6 | byte2);
        } else if ((byte1 & 240) === 224) {
          const byte2 = bytes[offset++] & 63;
          const byte3 = bytes[offset++] & 63;
          units.push((byte1 & 31) << 12 | byte2 << 6 | byte3);
        } else if ((byte1 & 248) === 240) {
          const byte2 = bytes[offset++] & 63;
          const byte3 = bytes[offset++] & 63;
          const byte4 = bytes[offset++] & 63;
          let unit = (byte1 & 7) << 18 | byte2 << 12 | byte3 << 6 | byte4;
          if (unit > 65535) {
            unit -= 65536;
            units.push(unit >>> 10 & 1023 | 55296);
            unit = 56320 | unit & 1023;
          }
          units.push(unit);
        } else {
          units.push(byte1);
        }
        if (units.length >= CHUNK_SIZE) {
          result += String.fromCharCode(...units);
          units.length = 0;
        }
      }
      if (units.length > 0) {
        result += String.fromCharCode(...units);
      }
      return result;
    }
    var sharedTextDecoder = new TextDecoder();
    var TEXT_DECODER_THRESHOLD = 200;
    function utf8DecodeTD(bytes, inputOffset, byteLength) {
      const stringBytes = bytes.subarray(inputOffset, inputOffset + byteLength);
      return sharedTextDecoder.decode(stringBytes);
    }
    function utf8Decode(bytes, inputOffset, byteLength) {
      if (byteLength > TEXT_DECODER_THRESHOLD) {
        return utf8DecodeTD(bytes, inputOffset, byteLength);
      } else {
        return utf8DecodeJs(bytes, inputOffset, byteLength);
      }
    }
  }
});

// ../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/ExtData.cjs
var require_ExtData = __commonJS({
  "../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/ExtData.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ExtData = void 0;
    var ExtData = class {
      type;
      data;
      constructor(type, data) {
        this.type = type;
        this.data = data;
      }
    };
    exports.ExtData = ExtData;
  }
});

// ../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/DecodeError.cjs
var require_DecodeError = __commonJS({
  "../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/DecodeError.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.DecodeError = void 0;
    var DecodeError = class _DecodeError extends Error {
      constructor(message) {
        super(message);
        const proto = Object.create(_DecodeError.prototype);
        Object.setPrototypeOf(this, proto);
        Object.defineProperty(this, "name", {
          configurable: true,
          enumerable: false,
          value: _DecodeError.name
        });
      }
    };
    exports.DecodeError = DecodeError;
  }
});

// ../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/utils/int.cjs
var require_int = __commonJS({
  "../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/utils/int.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.UINT32_MAX = void 0;
    exports.setUint64 = setUint64;
    exports.setInt64 = setInt64;
    exports.getInt64 = getInt64;
    exports.getUint64 = getUint64;
    exports.UINT32_MAX = 4294967295;
    function setUint64(view, offset, value) {
      const high = value / 4294967296;
      const low = value;
      view.setUint32(offset, high);
      view.setUint32(offset + 4, low);
    }
    function setInt64(view, offset, value) {
      const high = Math.floor(value / 4294967296);
      const low = value;
      view.setUint32(offset, high);
      view.setUint32(offset + 4, low);
    }
    function getInt64(view, offset) {
      const high = view.getInt32(offset);
      const low = view.getUint32(offset + 4);
      return high * 4294967296 + low;
    }
    function getUint64(view, offset) {
      const high = view.getUint32(offset);
      const low = view.getUint32(offset + 4);
      return high * 4294967296 + low;
    }
  }
});

// ../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/timestamp.cjs
var require_timestamp = __commonJS({
  "../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/timestamp.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.timestampExtension = exports.EXT_TIMESTAMP = void 0;
    exports.encodeTimeSpecToTimestamp = encodeTimeSpecToTimestamp;
    exports.encodeDateToTimeSpec = encodeDateToTimeSpec;
    exports.encodeTimestampExtension = encodeTimestampExtension;
    exports.decodeTimestampToTimeSpec = decodeTimestampToTimeSpec;
    exports.decodeTimestampExtension = decodeTimestampExtension;
    var DecodeError_ts_1 = require_DecodeError();
    var int_ts_1 = require_int();
    exports.EXT_TIMESTAMP = -1;
    var TIMESTAMP32_MAX_SEC = 4294967296 - 1;
    var TIMESTAMP64_MAX_SEC = 17179869184 - 1;
    function encodeTimeSpecToTimestamp({ sec, nsec }) {
      if (sec >= 0 && nsec >= 0 && sec <= TIMESTAMP64_MAX_SEC) {
        if (nsec === 0 && sec <= TIMESTAMP32_MAX_SEC) {
          const rv = new Uint8Array(4);
          const view = new DataView(rv.buffer);
          view.setUint32(0, sec);
          return rv;
        } else {
          const secHigh = sec / 4294967296;
          const secLow = sec & 4294967295;
          const rv = new Uint8Array(8);
          const view = new DataView(rv.buffer);
          view.setUint32(0, nsec << 2 | secHigh & 3);
          view.setUint32(4, secLow);
          return rv;
        }
      } else {
        const rv = new Uint8Array(12);
        const view = new DataView(rv.buffer);
        view.setUint32(0, nsec);
        (0, int_ts_1.setInt64)(view, 4, sec);
        return rv;
      }
    }
    function encodeDateToTimeSpec(date) {
      const msec = date.getTime();
      const sec = Math.floor(msec / 1e3);
      const nsec = (msec - sec * 1e3) * 1e6;
      const nsecInSec = Math.floor(nsec / 1e9);
      return {
        sec: sec + nsecInSec,
        nsec: nsec - nsecInSec * 1e9
      };
    }
    function encodeTimestampExtension(object) {
      if (object instanceof Date) {
        const timeSpec = encodeDateToTimeSpec(object);
        return encodeTimeSpecToTimestamp(timeSpec);
      } else {
        return null;
      }
    }
    function decodeTimestampToTimeSpec(data) {
      const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
      switch (data.byteLength) {
        case 4: {
          const sec = view.getUint32(0);
          const nsec = 0;
          return { sec, nsec };
        }
        case 8: {
          const nsec30AndSecHigh2 = view.getUint32(0);
          const secLow32 = view.getUint32(4);
          const sec = (nsec30AndSecHigh2 & 3) * 4294967296 + secLow32;
          const nsec = nsec30AndSecHigh2 >>> 2;
          return { sec, nsec };
        }
        case 12: {
          const sec = (0, int_ts_1.getInt64)(view, 4);
          const nsec = view.getUint32(0);
          return { sec, nsec };
        }
        default:
          throw new DecodeError_ts_1.DecodeError(`Unrecognized data size for timestamp (expected 4, 8, or 12): ${data.length}`);
      }
    }
    function decodeTimestampExtension(data) {
      const timeSpec = decodeTimestampToTimeSpec(data);
      return new Date(timeSpec.sec * 1e3 + timeSpec.nsec / 1e6);
    }
    exports.timestampExtension = {
      type: exports.EXT_TIMESTAMP,
      encode: encodeTimestampExtension,
      decode: decodeTimestampExtension
    };
  }
});

// ../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/ExtensionCodec.cjs
var require_ExtensionCodec = __commonJS({
  "../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/ExtensionCodec.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ExtensionCodec = void 0;
    var ExtData_ts_1 = require_ExtData();
    var timestamp_ts_1 = require_timestamp();
    var ExtensionCodec = class _ExtensionCodec {
      static defaultCodec = new _ExtensionCodec();
      // ensures ExtensionCodecType<X> matches ExtensionCodec<X>
      // this will make type errors a lot more clear
      // eslint-disable-next-line @typescript-eslint/naming-convention
      __brand;
      // built-in extensions
      builtInEncoders = [];
      builtInDecoders = [];
      // custom extensions
      encoders = [];
      decoders = [];
      constructor() {
        this.register(timestamp_ts_1.timestampExtension);
      }
      register({ type, encode: encode2, decode: decode2 }) {
        if (type >= 0) {
          this.encoders[type] = encode2;
          this.decoders[type] = decode2;
        } else {
          const index2 = -1 - type;
          this.builtInEncoders[index2] = encode2;
          this.builtInDecoders[index2] = decode2;
        }
      }
      tryToEncode(object, context) {
        for (let i = 0; i < this.builtInEncoders.length; i++) {
          const encodeExt = this.builtInEncoders[i];
          if (encodeExt != null) {
            const data = encodeExt(object, context);
            if (data != null) {
              const type = -1 - i;
              return new ExtData_ts_1.ExtData(type, data);
            }
          }
        }
        for (let i = 0; i < this.encoders.length; i++) {
          const encodeExt = this.encoders[i];
          if (encodeExt != null) {
            const data = encodeExt(object, context);
            if (data != null) {
              const type = i;
              return new ExtData_ts_1.ExtData(type, data);
            }
          }
        }
        if (object instanceof ExtData_ts_1.ExtData) {
          return object;
        }
        return null;
      }
      decode(data, type, context) {
        const decodeExt = type < 0 ? this.builtInDecoders[-1 - type] : this.decoders[type];
        if (decodeExt) {
          return decodeExt(data, type, context);
        } else {
          return new ExtData_ts_1.ExtData(type, data);
        }
      }
    };
    exports.ExtensionCodec = ExtensionCodec;
  }
});

// ../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/utils/typedArrays.cjs
var require_typedArrays = __commonJS({
  "../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/utils/typedArrays.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ensureUint8Array = ensureUint8Array;
    function isArrayBufferLike(buffer) {
      return buffer instanceof ArrayBuffer || typeof SharedArrayBuffer !== "undefined" && buffer instanceof SharedArrayBuffer;
    }
    function ensureUint8Array(buffer) {
      if (buffer instanceof Uint8Array) {
        return buffer;
      } else if (ArrayBuffer.isView(buffer)) {
        return new Uint8Array(buffer.buffer, buffer.byteOffset, buffer.byteLength);
      } else if (isArrayBufferLike(buffer)) {
        return new Uint8Array(buffer);
      } else {
        return Uint8Array.from(buffer);
      }
    }
  }
});

// ../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/Encoder.cjs
var require_Encoder = __commonJS({
  "../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/Encoder.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Encoder = exports.DEFAULT_INITIAL_BUFFER_SIZE = exports.DEFAULT_MAX_DEPTH = void 0;
    var utf8_ts_1 = require_utf8();
    var ExtensionCodec_ts_1 = require_ExtensionCodec();
    var int_ts_1 = require_int();
    var typedArrays_ts_1 = require_typedArrays();
    exports.DEFAULT_MAX_DEPTH = 100;
    exports.DEFAULT_INITIAL_BUFFER_SIZE = 2048;
    var Encoder = class _Encoder {
      extensionCodec;
      context;
      useBigInt64;
      maxDepth;
      initialBufferSize;
      sortKeys;
      forceFloat32;
      ignoreUndefined;
      forceIntegerToFloat;
      pos;
      view;
      bytes;
      entered = false;
      constructor(options) {
        this.extensionCodec = options?.extensionCodec ?? ExtensionCodec_ts_1.ExtensionCodec.defaultCodec;
        this.context = options?.context;
        this.useBigInt64 = options?.useBigInt64 ?? false;
        this.maxDepth = options?.maxDepth ?? exports.DEFAULT_MAX_DEPTH;
        this.initialBufferSize = options?.initialBufferSize ?? exports.DEFAULT_INITIAL_BUFFER_SIZE;
        this.sortKeys = options?.sortKeys ?? false;
        this.forceFloat32 = options?.forceFloat32 ?? false;
        this.ignoreUndefined = options?.ignoreUndefined ?? false;
        this.forceIntegerToFloat = options?.forceIntegerToFloat ?? false;
        this.pos = 0;
        this.view = new DataView(new ArrayBuffer(this.initialBufferSize));
        this.bytes = new Uint8Array(this.view.buffer);
      }
      clone() {
        return new _Encoder({
          extensionCodec: this.extensionCodec,
          context: this.context,
          useBigInt64: this.useBigInt64,
          maxDepth: this.maxDepth,
          initialBufferSize: this.initialBufferSize,
          sortKeys: this.sortKeys,
          forceFloat32: this.forceFloat32,
          ignoreUndefined: this.ignoreUndefined,
          forceIntegerToFloat: this.forceIntegerToFloat
        });
      }
      reinitializeState() {
        this.pos = 0;
      }
      /**
       * This is almost equivalent to {@link Encoder#encode}, but it returns an reference of the encoder's internal buffer and thus much faster than {@link Encoder#encode}.
       *
       * @returns Encodes the object and returns a shared reference the encoder's internal buffer.
       */
      encodeSharedRef(object) {
        if (this.entered) {
          const instance = this.clone();
          return instance.encodeSharedRef(object);
        }
        try {
          this.entered = true;
          this.reinitializeState();
          this.doEncode(object, 1);
          return this.bytes.subarray(0, this.pos);
        } finally {
          this.entered = false;
        }
      }
      /**
       * @returns Encodes the object and returns a copy of the encoder's internal buffer.
       */
      encode(object) {
        if (this.entered) {
          const instance = this.clone();
          return instance.encode(object);
        }
        try {
          this.entered = true;
          this.reinitializeState();
          this.doEncode(object, 1);
          return this.bytes.slice(0, this.pos);
        } finally {
          this.entered = false;
        }
      }
      doEncode(object, depth) {
        if (depth > this.maxDepth) {
          throw new Error(`Too deep objects in depth ${depth}`);
        }
        if (object == null) {
          this.encodeNil();
        } else if (typeof object === "boolean") {
          this.encodeBoolean(object);
        } else if (typeof object === "number") {
          if (!this.forceIntegerToFloat) {
            this.encodeNumber(object);
          } else {
            this.encodeNumberAsFloat(object);
          }
        } else if (typeof object === "string") {
          this.encodeString(object);
        } else if (this.useBigInt64 && typeof object === "bigint") {
          this.encodeBigInt64(object);
        } else {
          this.encodeObject(object, depth);
        }
      }
      ensureBufferSizeToWrite(sizeToWrite) {
        const requiredSize = this.pos + sizeToWrite;
        if (this.view.byteLength < requiredSize) {
          this.resizeBuffer(requiredSize * 2);
        }
      }
      resizeBuffer(newSize) {
        const newBuffer = new ArrayBuffer(newSize);
        const newBytes = new Uint8Array(newBuffer);
        const newView = new DataView(newBuffer);
        newBytes.set(this.bytes);
        this.view = newView;
        this.bytes = newBytes;
      }
      encodeNil() {
        this.writeU8(192);
      }
      encodeBoolean(object) {
        if (object === false) {
          this.writeU8(194);
        } else {
          this.writeU8(195);
        }
      }
      encodeNumber(object) {
        if (!this.forceIntegerToFloat && Number.isSafeInteger(object)) {
          if (object >= 0) {
            if (object < 128) {
              this.writeU8(object);
            } else if (object < 256) {
              this.writeU8(204);
              this.writeU8(object);
            } else if (object < 65536) {
              this.writeU8(205);
              this.writeU16(object);
            } else if (object < 4294967296) {
              this.writeU8(206);
              this.writeU32(object);
            } else if (!this.useBigInt64) {
              this.writeU8(207);
              this.writeU64(object);
            } else {
              this.encodeNumberAsFloat(object);
            }
          } else {
            if (object >= -32) {
              this.writeU8(224 | object + 32);
            } else if (object >= -128) {
              this.writeU8(208);
              this.writeI8(object);
            } else if (object >= -32768) {
              this.writeU8(209);
              this.writeI16(object);
            } else if (object >= -2147483648) {
              this.writeU8(210);
              this.writeI32(object);
            } else if (!this.useBigInt64) {
              this.writeU8(211);
              this.writeI64(object);
            } else {
              this.encodeNumberAsFloat(object);
            }
          }
        } else {
          this.encodeNumberAsFloat(object);
        }
      }
      encodeNumberAsFloat(object) {
        if (this.forceFloat32) {
          this.writeU8(202);
          this.writeF32(object);
        } else {
          this.writeU8(203);
          this.writeF64(object);
        }
      }
      encodeBigInt64(object) {
        if (object >= BigInt(0)) {
          this.writeU8(207);
          this.writeBigUint64(object);
        } else {
          this.writeU8(211);
          this.writeBigInt64(object);
        }
      }
      writeStringHeader(byteLength) {
        if (byteLength < 32) {
          this.writeU8(160 + byteLength);
        } else if (byteLength < 256) {
          this.writeU8(217);
          this.writeU8(byteLength);
        } else if (byteLength < 65536) {
          this.writeU8(218);
          this.writeU16(byteLength);
        } else if (byteLength < 4294967296) {
          this.writeU8(219);
          this.writeU32(byteLength);
        } else {
          throw new Error(`Too long string: ${byteLength} bytes in UTF-8`);
        }
      }
      encodeString(object) {
        const maxHeaderSize = 1 + 4;
        const byteLength = (0, utf8_ts_1.utf8Count)(object);
        this.ensureBufferSizeToWrite(maxHeaderSize + byteLength);
        this.writeStringHeader(byteLength);
        (0, utf8_ts_1.utf8Encode)(object, this.bytes, this.pos);
        this.pos += byteLength;
      }
      encodeObject(object, depth) {
        const ext = this.extensionCodec.tryToEncode(object, this.context);
        if (ext != null) {
          this.encodeExtension(ext);
        } else if (Array.isArray(object)) {
          this.encodeArray(object, depth);
        } else if (ArrayBuffer.isView(object)) {
          this.encodeBinary(object);
        } else if (typeof object === "object") {
          this.encodeMap(object, depth);
        } else {
          throw new Error(`Unrecognized object: ${Object.prototype.toString.apply(object)}`);
        }
      }
      encodeBinary(object) {
        const size = object.byteLength;
        if (size < 256) {
          this.writeU8(196);
          this.writeU8(size);
        } else if (size < 65536) {
          this.writeU8(197);
          this.writeU16(size);
        } else if (size < 4294967296) {
          this.writeU8(198);
          this.writeU32(size);
        } else {
          throw new Error(`Too large binary: ${size}`);
        }
        const bytes = (0, typedArrays_ts_1.ensureUint8Array)(object);
        this.writeU8a(bytes);
      }
      encodeArray(object, depth) {
        const size = object.length;
        if (size < 16) {
          this.writeU8(144 + size);
        } else if (size < 65536) {
          this.writeU8(220);
          this.writeU16(size);
        } else if (size < 4294967296) {
          this.writeU8(221);
          this.writeU32(size);
        } else {
          throw new Error(`Too large array: ${size}`);
        }
        for (const item of object) {
          this.doEncode(item, depth + 1);
        }
      }
      countWithoutUndefined(object, keys) {
        let count = 0;
        for (const key of keys) {
          if (object[key] !== void 0) {
            count++;
          }
        }
        return count;
      }
      encodeMap(object, depth) {
        const keys = Object.keys(object);
        if (this.sortKeys) {
          keys.sort();
        }
        const size = this.ignoreUndefined ? this.countWithoutUndefined(object, keys) : keys.length;
        if (size < 16) {
          this.writeU8(128 + size);
        } else if (size < 65536) {
          this.writeU8(222);
          this.writeU16(size);
        } else if (size < 4294967296) {
          this.writeU8(223);
          this.writeU32(size);
        } else {
          throw new Error(`Too large map object: ${size}`);
        }
        for (const key of keys) {
          const value = object[key];
          if (!(this.ignoreUndefined && value === void 0)) {
            this.encodeString(key);
            this.doEncode(value, depth + 1);
          }
        }
      }
      encodeExtension(ext) {
        if (typeof ext.data === "function") {
          const data = ext.data(this.pos + 6);
          const size2 = data.length;
          if (size2 >= 4294967296) {
            throw new Error(`Too large extension object: ${size2}`);
          }
          this.writeU8(201);
          this.writeU32(size2);
          this.writeI8(ext.type);
          this.writeU8a(data);
          return;
        }
        const size = ext.data.length;
        if (size === 1) {
          this.writeU8(212);
        } else if (size === 2) {
          this.writeU8(213);
        } else if (size === 4) {
          this.writeU8(214);
        } else if (size === 8) {
          this.writeU8(215);
        } else if (size === 16) {
          this.writeU8(216);
        } else if (size < 256) {
          this.writeU8(199);
          this.writeU8(size);
        } else if (size < 65536) {
          this.writeU8(200);
          this.writeU16(size);
        } else if (size < 4294967296) {
          this.writeU8(201);
          this.writeU32(size);
        } else {
          throw new Error(`Too large extension object: ${size}`);
        }
        this.writeI8(ext.type);
        this.writeU8a(ext.data);
      }
      writeU8(value) {
        this.ensureBufferSizeToWrite(1);
        this.view.setUint8(this.pos, value);
        this.pos++;
      }
      writeU8a(values) {
        const size = values.length;
        this.ensureBufferSizeToWrite(size);
        this.bytes.set(values, this.pos);
        this.pos += size;
      }
      writeI8(value) {
        this.ensureBufferSizeToWrite(1);
        this.view.setInt8(this.pos, value);
        this.pos++;
      }
      writeU16(value) {
        this.ensureBufferSizeToWrite(2);
        this.view.setUint16(this.pos, value);
        this.pos += 2;
      }
      writeI16(value) {
        this.ensureBufferSizeToWrite(2);
        this.view.setInt16(this.pos, value);
        this.pos += 2;
      }
      writeU32(value) {
        this.ensureBufferSizeToWrite(4);
        this.view.setUint32(this.pos, value);
        this.pos += 4;
      }
      writeI32(value) {
        this.ensureBufferSizeToWrite(4);
        this.view.setInt32(this.pos, value);
        this.pos += 4;
      }
      writeF32(value) {
        this.ensureBufferSizeToWrite(4);
        this.view.setFloat32(this.pos, value);
        this.pos += 4;
      }
      writeF64(value) {
        this.ensureBufferSizeToWrite(8);
        this.view.setFloat64(this.pos, value);
        this.pos += 8;
      }
      writeU64(value) {
        this.ensureBufferSizeToWrite(8);
        (0, int_ts_1.setUint64)(this.view, this.pos, value);
        this.pos += 8;
      }
      writeI64(value) {
        this.ensureBufferSizeToWrite(8);
        (0, int_ts_1.setInt64)(this.view, this.pos, value);
        this.pos += 8;
      }
      writeBigUint64(value) {
        this.ensureBufferSizeToWrite(8);
        this.view.setBigUint64(this.pos, value);
        this.pos += 8;
      }
      writeBigInt64(value) {
        this.ensureBufferSizeToWrite(8);
        this.view.setBigInt64(this.pos, value);
        this.pos += 8;
      }
    };
    exports.Encoder = Encoder;
  }
});

// ../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/encode.cjs
var require_encode = __commonJS({
  "../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/encode.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.encode = encode2;
    var Encoder_ts_1 = require_Encoder();
    function encode2(value, options) {
      const encoder = new Encoder_ts_1.Encoder(options);
      return encoder.encodeSharedRef(value);
    }
  }
});

// ../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/utils/prettyByte.cjs
var require_prettyByte = __commonJS({
  "../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/utils/prettyByte.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.prettyByte = prettyByte;
    function prettyByte(byte) {
      return `${byte < 0 ? "-" : ""}0x${Math.abs(byte).toString(16).padStart(2, "0")}`;
    }
  }
});

// ../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/CachedKeyDecoder.cjs
var require_CachedKeyDecoder = __commonJS({
  "../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/CachedKeyDecoder.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CachedKeyDecoder = void 0;
    var utf8_ts_1 = require_utf8();
    var DEFAULT_MAX_KEY_LENGTH = 16;
    var DEFAULT_MAX_LENGTH_PER_KEY = 16;
    var CachedKeyDecoder = class {
      hit = 0;
      miss = 0;
      caches;
      maxKeyLength;
      maxLengthPerKey;
      constructor(maxKeyLength = DEFAULT_MAX_KEY_LENGTH, maxLengthPerKey = DEFAULT_MAX_LENGTH_PER_KEY) {
        this.maxKeyLength = maxKeyLength;
        this.maxLengthPerKey = maxLengthPerKey;
        this.caches = [];
        for (let i = 0; i < this.maxKeyLength; i++) {
          this.caches.push([]);
        }
      }
      canBeCached(byteLength) {
        return byteLength > 0 && byteLength <= this.maxKeyLength;
      }
      find(bytes, inputOffset, byteLength) {
        const records = this.caches[byteLength - 1];
        FIND_CHUNK: for (const record of records) {
          const recordBytes = record.bytes;
          for (let j = 0; j < byteLength; j++) {
            if (recordBytes[j] !== bytes[inputOffset + j]) {
              continue FIND_CHUNK;
            }
          }
          return record.str;
        }
        return null;
      }
      store(bytes, value) {
        const records = this.caches[bytes.length - 1];
        const record = { bytes, str: value };
        if (records.length >= this.maxLengthPerKey) {
          records[Math.random() * records.length | 0] = record;
        } else {
          records.push(record);
        }
      }
      decode(bytes, inputOffset, byteLength) {
        const cachedValue = this.find(bytes, inputOffset, byteLength);
        if (cachedValue != null) {
          this.hit++;
          return cachedValue;
        }
        this.miss++;
        const str = (0, utf8_ts_1.utf8DecodeJs)(bytes, inputOffset, byteLength);
        const slicedCopyOfBytes = Uint8Array.prototype.slice.call(bytes, inputOffset, inputOffset + byteLength);
        this.store(slicedCopyOfBytes, str);
        return str;
      }
    };
    exports.CachedKeyDecoder = CachedKeyDecoder;
  }
});

// ../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/Decoder.cjs
var require_Decoder = __commonJS({
  "../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/Decoder.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Decoder = void 0;
    var prettyByte_ts_1 = require_prettyByte();
    var ExtensionCodec_ts_1 = require_ExtensionCodec();
    var int_ts_1 = require_int();
    var utf8_ts_1 = require_utf8();
    var typedArrays_ts_1 = require_typedArrays();
    var CachedKeyDecoder_ts_1 = require_CachedKeyDecoder();
    var DecodeError_ts_1 = require_DecodeError();
    var STATE_ARRAY = "array";
    var STATE_MAP_KEY = "map_key";
    var STATE_MAP_VALUE = "map_value";
    var mapKeyConverter = (key) => {
      if (typeof key === "string" || typeof key === "number") {
        return key;
      }
      throw new DecodeError_ts_1.DecodeError("The type of key must be string or number but " + typeof key);
    };
    var StackPool = class {
      stack = [];
      stackHeadPosition = -1;
      get length() {
        return this.stackHeadPosition + 1;
      }
      top() {
        return this.stack[this.stackHeadPosition];
      }
      pushArrayState(size) {
        const state = this.getUninitializedStateFromPool();
        state.type = STATE_ARRAY;
        state.position = 0;
        state.size = size;
        state.array = new Array(size);
      }
      pushMapState(size) {
        const state = this.getUninitializedStateFromPool();
        state.type = STATE_MAP_KEY;
        state.readCount = 0;
        state.size = size;
        state.map = {};
      }
      getUninitializedStateFromPool() {
        this.stackHeadPosition++;
        if (this.stackHeadPosition === this.stack.length) {
          const partialState = {
            type: void 0,
            size: 0,
            array: void 0,
            position: 0,
            readCount: 0,
            map: void 0,
            key: null
          };
          this.stack.push(partialState);
        }
        return this.stack[this.stackHeadPosition];
      }
      release(state) {
        const topStackState = this.stack[this.stackHeadPosition];
        if (topStackState !== state) {
          throw new Error("Invalid stack state. Released state is not on top of the stack.");
        }
        if (state.type === STATE_ARRAY) {
          const partialState = state;
          partialState.size = 0;
          partialState.array = void 0;
          partialState.position = 0;
          partialState.type = void 0;
        }
        if (state.type === STATE_MAP_KEY || state.type === STATE_MAP_VALUE) {
          const partialState = state;
          partialState.size = 0;
          partialState.map = void 0;
          partialState.readCount = 0;
          partialState.type = void 0;
        }
        this.stackHeadPosition--;
      }
      reset() {
        this.stack.length = 0;
        this.stackHeadPosition = -1;
      }
    };
    var HEAD_BYTE_REQUIRED = -1;
    var EMPTY_VIEW = new DataView(new ArrayBuffer(0));
    var EMPTY_BYTES = new Uint8Array(EMPTY_VIEW.buffer);
    try {
      EMPTY_VIEW.getInt8(0);
    } catch (e) {
      if (!(e instanceof RangeError)) {
        throw new Error("This module is not supported in the current JavaScript engine because DataView does not throw RangeError on out-of-bounds access");
      }
    }
    var MORE_DATA = new RangeError("Insufficient data");
    var sharedCachedKeyDecoder = new CachedKeyDecoder_ts_1.CachedKeyDecoder();
    var Decoder = class _Decoder {
      extensionCodec;
      context;
      useBigInt64;
      rawStrings;
      maxStrLength;
      maxBinLength;
      maxArrayLength;
      maxMapLength;
      maxExtLength;
      keyDecoder;
      mapKeyConverter;
      totalPos = 0;
      pos = 0;
      view = EMPTY_VIEW;
      bytes = EMPTY_BYTES;
      headByte = HEAD_BYTE_REQUIRED;
      stack = new StackPool();
      entered = false;
      constructor(options) {
        this.extensionCodec = options?.extensionCodec ?? ExtensionCodec_ts_1.ExtensionCodec.defaultCodec;
        this.context = options?.context;
        this.useBigInt64 = options?.useBigInt64 ?? false;
        this.rawStrings = options?.rawStrings ?? false;
        this.maxStrLength = options?.maxStrLength ?? int_ts_1.UINT32_MAX;
        this.maxBinLength = options?.maxBinLength ?? int_ts_1.UINT32_MAX;
        this.maxArrayLength = options?.maxArrayLength ?? int_ts_1.UINT32_MAX;
        this.maxMapLength = options?.maxMapLength ?? int_ts_1.UINT32_MAX;
        this.maxExtLength = options?.maxExtLength ?? int_ts_1.UINT32_MAX;
        this.keyDecoder = options?.keyDecoder !== void 0 ? options.keyDecoder : sharedCachedKeyDecoder;
        this.mapKeyConverter = options?.mapKeyConverter ?? mapKeyConverter;
      }
      clone() {
        return new _Decoder({
          extensionCodec: this.extensionCodec,
          context: this.context,
          useBigInt64: this.useBigInt64,
          rawStrings: this.rawStrings,
          maxStrLength: this.maxStrLength,
          maxBinLength: this.maxBinLength,
          maxArrayLength: this.maxArrayLength,
          maxMapLength: this.maxMapLength,
          maxExtLength: this.maxExtLength,
          keyDecoder: this.keyDecoder
        });
      }
      reinitializeState() {
        this.totalPos = 0;
        this.headByte = HEAD_BYTE_REQUIRED;
        this.stack.reset();
      }
      setBuffer(buffer) {
        const bytes = (0, typedArrays_ts_1.ensureUint8Array)(buffer);
        this.bytes = bytes;
        this.view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        this.pos = 0;
      }
      appendBuffer(buffer) {
        if (this.headByte === HEAD_BYTE_REQUIRED && !this.hasRemaining(1)) {
          this.setBuffer(buffer);
        } else {
          const remainingData = this.bytes.subarray(this.pos);
          const newData = (0, typedArrays_ts_1.ensureUint8Array)(buffer);
          const newBuffer = new Uint8Array(remainingData.length + newData.length);
          newBuffer.set(remainingData);
          newBuffer.set(newData, remainingData.length);
          this.setBuffer(newBuffer);
        }
      }
      hasRemaining(size) {
        return this.view.byteLength - this.pos >= size;
      }
      createExtraByteError(posToShow) {
        const { view, pos } = this;
        return new RangeError(`Extra ${view.byteLength - pos} of ${view.byteLength} byte(s) found at buffer[${posToShow}]`);
      }
      /**
       * @throws {@link DecodeError}
       * @throws {@link RangeError}
       */
      decode(buffer) {
        if (this.entered) {
          const instance = this.clone();
          return instance.decode(buffer);
        }
        try {
          this.entered = true;
          this.reinitializeState();
          this.setBuffer(buffer);
          const object = this.doDecodeSync();
          if (this.hasRemaining(1)) {
            throw this.createExtraByteError(this.pos);
          }
          return object;
        } finally {
          this.entered = false;
        }
      }
      *decodeMulti(buffer) {
        if (this.entered) {
          const instance = this.clone();
          yield* instance.decodeMulti(buffer);
          return;
        }
        try {
          this.entered = true;
          this.reinitializeState();
          this.setBuffer(buffer);
          while (this.hasRemaining(1)) {
            yield this.doDecodeSync();
          }
        } finally {
          this.entered = false;
        }
      }
      async decodeAsync(stream) {
        if (this.entered) {
          const instance = this.clone();
          return instance.decodeAsync(stream);
        }
        try {
          this.entered = true;
          let decoded = false;
          let object;
          for await (const buffer of stream) {
            if (decoded) {
              this.entered = false;
              throw this.createExtraByteError(this.totalPos);
            }
            this.appendBuffer(buffer);
            try {
              object = this.doDecodeSync();
              decoded = true;
            } catch (e) {
              if (!(e instanceof RangeError)) {
                throw e;
              }
            }
            this.totalPos += this.pos;
          }
          if (decoded) {
            if (this.hasRemaining(1)) {
              throw this.createExtraByteError(this.totalPos);
            }
            return object;
          }
          const { headByte, pos, totalPos } = this;
          throw new RangeError(`Insufficient data in parsing ${(0, prettyByte_ts_1.prettyByte)(headByte)} at ${totalPos} (${pos} in the current buffer)`);
        } finally {
          this.entered = false;
        }
      }
      decodeArrayStream(stream) {
        return this.decodeMultiAsync(stream, true);
      }
      decodeStream(stream) {
        return this.decodeMultiAsync(stream, false);
      }
      async *decodeMultiAsync(stream, isArray) {
        if (this.entered) {
          const instance = this.clone();
          yield* instance.decodeMultiAsync(stream, isArray);
          return;
        }
        try {
          this.entered = true;
          let isArrayHeaderRequired = isArray;
          let arrayItemsLeft = -1;
          for await (const buffer of stream) {
            if (isArray && arrayItemsLeft === 0) {
              throw this.createExtraByteError(this.totalPos);
            }
            this.appendBuffer(buffer);
            if (isArrayHeaderRequired) {
              arrayItemsLeft = this.readArraySize();
              isArrayHeaderRequired = false;
              this.complete();
            }
            try {
              while (true) {
                yield this.doDecodeSync();
                if (--arrayItemsLeft === 0) {
                  break;
                }
              }
            } catch (e) {
              if (!(e instanceof RangeError)) {
                throw e;
              }
            }
            this.totalPos += this.pos;
          }
        } finally {
          this.entered = false;
        }
      }
      doDecodeSync() {
        DECODE: while (true) {
          const headByte = this.readHeadByte();
          let object;
          if (headByte >= 224) {
            object = headByte - 256;
          } else if (headByte < 192) {
            if (headByte < 128) {
              object = headByte;
            } else if (headByte < 144) {
              const size = headByte - 128;
              if (size !== 0) {
                this.pushMapState(size);
                this.complete();
                continue DECODE;
              } else {
                object = {};
              }
            } else if (headByte < 160) {
              const size = headByte - 144;
              if (size !== 0) {
                this.pushArrayState(size);
                this.complete();
                continue DECODE;
              } else {
                object = [];
              }
            } else {
              const byteLength = headByte - 160;
              object = this.decodeString(byteLength, 0);
            }
          } else if (headByte === 192) {
            object = null;
          } else if (headByte === 194) {
            object = false;
          } else if (headByte === 195) {
            object = true;
          } else if (headByte === 202) {
            object = this.readF32();
          } else if (headByte === 203) {
            object = this.readF64();
          } else if (headByte === 204) {
            object = this.readU8();
          } else if (headByte === 205) {
            object = this.readU16();
          } else if (headByte === 206) {
            object = this.readU32();
          } else if (headByte === 207) {
            if (this.useBigInt64) {
              object = this.readU64AsBigInt();
            } else {
              object = this.readU64();
            }
          } else if (headByte === 208) {
            object = this.readI8();
          } else if (headByte === 209) {
            object = this.readI16();
          } else if (headByte === 210) {
            object = this.readI32();
          } else if (headByte === 211) {
            if (this.useBigInt64) {
              object = this.readI64AsBigInt();
            } else {
              object = this.readI64();
            }
          } else if (headByte === 217) {
            const byteLength = this.lookU8();
            object = this.decodeString(byteLength, 1);
          } else if (headByte === 218) {
            const byteLength = this.lookU16();
            object = this.decodeString(byteLength, 2);
          } else if (headByte === 219) {
            const byteLength = this.lookU32();
            object = this.decodeString(byteLength, 4);
          } else if (headByte === 220) {
            const size = this.readU16();
            if (size !== 0) {
              this.pushArrayState(size);
              this.complete();
              continue DECODE;
            } else {
              object = [];
            }
          } else if (headByte === 221) {
            const size = this.readU32();
            if (size !== 0) {
              this.pushArrayState(size);
              this.complete();
              continue DECODE;
            } else {
              object = [];
            }
          } else if (headByte === 222) {
            const size = this.readU16();
            if (size !== 0) {
              this.pushMapState(size);
              this.complete();
              continue DECODE;
            } else {
              object = {};
            }
          } else if (headByte === 223) {
            const size = this.readU32();
            if (size !== 0) {
              this.pushMapState(size);
              this.complete();
              continue DECODE;
            } else {
              object = {};
            }
          } else if (headByte === 196) {
            const size = this.lookU8();
            object = this.decodeBinary(size, 1);
          } else if (headByte === 197) {
            const size = this.lookU16();
            object = this.decodeBinary(size, 2);
          } else if (headByte === 198) {
            const size = this.lookU32();
            object = this.decodeBinary(size, 4);
          } else if (headByte === 212) {
            object = this.decodeExtension(1, 0);
          } else if (headByte === 213) {
            object = this.decodeExtension(2, 0);
          } else if (headByte === 214) {
            object = this.decodeExtension(4, 0);
          } else if (headByte === 215) {
            object = this.decodeExtension(8, 0);
          } else if (headByte === 216) {
            object = this.decodeExtension(16, 0);
          } else if (headByte === 199) {
            const size = this.lookU8();
            object = this.decodeExtension(size, 1);
          } else if (headByte === 200) {
            const size = this.lookU16();
            object = this.decodeExtension(size, 2);
          } else if (headByte === 201) {
            const size = this.lookU32();
            object = this.decodeExtension(size, 4);
          } else {
            throw new DecodeError_ts_1.DecodeError(`Unrecognized type byte: ${(0, prettyByte_ts_1.prettyByte)(headByte)}`);
          }
          this.complete();
          const stack = this.stack;
          while (stack.length > 0) {
            const state = stack.top();
            if (state.type === STATE_ARRAY) {
              state.array[state.position] = object;
              state.position++;
              if (state.position === state.size) {
                object = state.array;
                stack.release(state);
              } else {
                continue DECODE;
              }
            } else if (state.type === STATE_MAP_KEY) {
              if (object === "__proto__") {
                throw new DecodeError_ts_1.DecodeError("The key __proto__ is not allowed");
              }
              state.key = this.mapKeyConverter(object);
              state.type = STATE_MAP_VALUE;
              continue DECODE;
            } else {
              state.map[state.key] = object;
              state.readCount++;
              if (state.readCount === state.size) {
                object = state.map;
                stack.release(state);
              } else {
                state.key = null;
                state.type = STATE_MAP_KEY;
                continue DECODE;
              }
            }
          }
          return object;
        }
      }
      readHeadByte() {
        if (this.headByte === HEAD_BYTE_REQUIRED) {
          this.headByte = this.readU8();
        }
        return this.headByte;
      }
      complete() {
        this.headByte = HEAD_BYTE_REQUIRED;
      }
      readArraySize() {
        const headByte = this.readHeadByte();
        switch (headByte) {
          case 220:
            return this.readU16();
          case 221:
            return this.readU32();
          default: {
            if (headByte < 160) {
              return headByte - 144;
            } else {
              throw new DecodeError_ts_1.DecodeError(`Unrecognized array type byte: ${(0, prettyByte_ts_1.prettyByte)(headByte)}`);
            }
          }
        }
      }
      pushMapState(size) {
        if (size > this.maxMapLength) {
          throw new DecodeError_ts_1.DecodeError(`Max length exceeded: map length (${size}) > maxMapLengthLength (${this.maxMapLength})`);
        }
        this.stack.pushMapState(size);
      }
      pushArrayState(size) {
        if (size > this.maxArrayLength) {
          throw new DecodeError_ts_1.DecodeError(`Max length exceeded: array length (${size}) > maxArrayLength (${this.maxArrayLength})`);
        }
        this.stack.pushArrayState(size);
      }
      decodeString(byteLength, headerOffset) {
        if (!this.rawStrings || this.stateIsMapKey()) {
          return this.decodeUtf8String(byteLength, headerOffset);
        }
        return this.decodeBinary(byteLength, headerOffset);
      }
      /**
       * @throws {@link RangeError}
       */
      decodeUtf8String(byteLength, headerOffset) {
        if (byteLength > this.maxStrLength) {
          throw new DecodeError_ts_1.DecodeError(`Max length exceeded: UTF-8 byte length (${byteLength}) > maxStrLength (${this.maxStrLength})`);
        }
        if (this.bytes.byteLength < this.pos + headerOffset + byteLength) {
          throw MORE_DATA;
        }
        const offset = this.pos + headerOffset;
        let object;
        if (this.stateIsMapKey() && this.keyDecoder?.canBeCached(byteLength)) {
          object = this.keyDecoder.decode(this.bytes, offset, byteLength);
        } else {
          object = (0, utf8_ts_1.utf8Decode)(this.bytes, offset, byteLength);
        }
        this.pos += headerOffset + byteLength;
        return object;
      }
      stateIsMapKey() {
        if (this.stack.length > 0) {
          const state = this.stack.top();
          return state.type === STATE_MAP_KEY;
        }
        return false;
      }
      /**
       * @throws {@link RangeError}
       */
      decodeBinary(byteLength, headOffset) {
        if (byteLength > this.maxBinLength) {
          throw new DecodeError_ts_1.DecodeError(`Max length exceeded: bin length (${byteLength}) > maxBinLength (${this.maxBinLength})`);
        }
        if (!this.hasRemaining(byteLength + headOffset)) {
          throw MORE_DATA;
        }
        const offset = this.pos + headOffset;
        const object = this.bytes.subarray(offset, offset + byteLength);
        this.pos += headOffset + byteLength;
        return object;
      }
      decodeExtension(size, headOffset) {
        if (size > this.maxExtLength) {
          throw new DecodeError_ts_1.DecodeError(`Max length exceeded: ext length (${size}) > maxExtLength (${this.maxExtLength})`);
        }
        const extType = this.view.getInt8(this.pos + headOffset);
        const data = this.decodeBinary(
          size,
          headOffset + 1
          /* extType */
        );
        return this.extensionCodec.decode(data, extType, this.context);
      }
      lookU8() {
        return this.view.getUint8(this.pos);
      }
      lookU16() {
        return this.view.getUint16(this.pos);
      }
      lookU32() {
        return this.view.getUint32(this.pos);
      }
      readU8() {
        const value = this.view.getUint8(this.pos);
        this.pos++;
        return value;
      }
      readI8() {
        const value = this.view.getInt8(this.pos);
        this.pos++;
        return value;
      }
      readU16() {
        const value = this.view.getUint16(this.pos);
        this.pos += 2;
        return value;
      }
      readI16() {
        const value = this.view.getInt16(this.pos);
        this.pos += 2;
        return value;
      }
      readU32() {
        const value = this.view.getUint32(this.pos);
        this.pos += 4;
        return value;
      }
      readI32() {
        const value = this.view.getInt32(this.pos);
        this.pos += 4;
        return value;
      }
      readU64() {
        const value = (0, int_ts_1.getUint64)(this.view, this.pos);
        this.pos += 8;
        return value;
      }
      readI64() {
        const value = (0, int_ts_1.getInt64)(this.view, this.pos);
        this.pos += 8;
        return value;
      }
      readU64AsBigInt() {
        const value = this.view.getBigUint64(this.pos);
        this.pos += 8;
        return value;
      }
      readI64AsBigInt() {
        const value = this.view.getBigInt64(this.pos);
        this.pos += 8;
        return value;
      }
      readF32() {
        const value = this.view.getFloat32(this.pos);
        this.pos += 4;
        return value;
      }
      readF64() {
        const value = this.view.getFloat64(this.pos);
        this.pos += 8;
        return value;
      }
    };
    exports.Decoder = Decoder;
  }
});

// ../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/decode.cjs
var require_decode = __commonJS({
  "../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/decode.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.decode = decode2;
    exports.decodeMulti = decodeMulti;
    var Decoder_ts_1 = require_Decoder();
    function decode2(buffer, options) {
      const decoder = new Decoder_ts_1.Decoder(options);
      return decoder.decode(buffer);
    }
    function decodeMulti(buffer, options) {
      const decoder = new Decoder_ts_1.Decoder(options);
      return decoder.decodeMulti(buffer);
    }
  }
});

// ../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/utils/stream.cjs
var require_stream = __commonJS({
  "../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/utils/stream.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.isAsyncIterable = isAsyncIterable;
    exports.asyncIterableFromStream = asyncIterableFromStream;
    exports.ensureAsyncIterable = ensureAsyncIterable;
    function isAsyncIterable(object) {
      return object[Symbol.asyncIterator] != null;
    }
    async function* asyncIterableFromStream(stream) {
      const reader = stream.getReader();
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) {
            return;
          }
          yield value;
        }
      } finally {
        reader.releaseLock();
      }
    }
    function ensureAsyncIterable(streamLike) {
      if (isAsyncIterable(streamLike)) {
        return streamLike;
      } else {
        return asyncIterableFromStream(streamLike);
      }
    }
  }
});

// ../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/decodeAsync.cjs
var require_decodeAsync = __commonJS({
  "../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/decodeAsync.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.decodeAsync = decodeAsync;
    exports.decodeArrayStream = decodeArrayStream;
    exports.decodeMultiStream = decodeMultiStream;
    var Decoder_ts_1 = require_Decoder();
    var stream_ts_1 = require_stream();
    async function decodeAsync(streamLike, options) {
      const stream = (0, stream_ts_1.ensureAsyncIterable)(streamLike);
      const decoder = new Decoder_ts_1.Decoder(options);
      return decoder.decodeAsync(stream);
    }
    function decodeArrayStream(streamLike, options) {
      const stream = (0, stream_ts_1.ensureAsyncIterable)(streamLike);
      const decoder = new Decoder_ts_1.Decoder(options);
      return decoder.decodeArrayStream(stream);
    }
    function decodeMultiStream(streamLike, options) {
      const stream = (0, stream_ts_1.ensureAsyncIterable)(streamLike);
      const decoder = new Decoder_ts_1.Decoder(options);
      return decoder.decodeStream(stream);
    }
  }
});

// ../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/index.cjs
var require_dist = __commonJS({
  "../../node_modules/.bun/@msgpack+msgpack@3.1.3/node_modules/@msgpack/msgpack/dist.cjs/index.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.decodeTimestampExtension = exports.encodeTimestampExtension = exports.decodeTimestampToTimeSpec = exports.encodeTimeSpecToTimestamp = exports.encodeDateToTimeSpec = exports.EXT_TIMESTAMP = exports.ExtData = exports.ExtensionCodec = exports.Encoder = exports.DecodeError = exports.Decoder = exports.decodeMultiStream = exports.decodeArrayStream = exports.decodeAsync = exports.decodeMulti = exports.decode = exports.encode = void 0;
    var encode_ts_1 = require_encode();
    Object.defineProperty(exports, "encode", { enumerable: true, get: function() {
      return encode_ts_1.encode;
    } });
    var decode_ts_1 = require_decode();
    Object.defineProperty(exports, "decode", { enumerable: true, get: function() {
      return decode_ts_1.decode;
    } });
    Object.defineProperty(exports, "decodeMulti", { enumerable: true, get: function() {
      return decode_ts_1.decodeMulti;
    } });
    var decodeAsync_ts_1 = require_decodeAsync();
    Object.defineProperty(exports, "decodeAsync", { enumerable: true, get: function() {
      return decodeAsync_ts_1.decodeAsync;
    } });
    Object.defineProperty(exports, "decodeArrayStream", { enumerable: true, get: function() {
      return decodeAsync_ts_1.decodeArrayStream;
    } });
    Object.defineProperty(exports, "decodeMultiStream", { enumerable: true, get: function() {
      return decodeAsync_ts_1.decodeMultiStream;
    } });
    var Decoder_ts_1 = require_Decoder();
    Object.defineProperty(exports, "Decoder", { enumerable: true, get: function() {
      return Decoder_ts_1.Decoder;
    } });
    var DecodeError_ts_1 = require_DecodeError();
    Object.defineProperty(exports, "DecodeError", { enumerable: true, get: function() {
      return DecodeError_ts_1.DecodeError;
    } });
    var Encoder_ts_1 = require_Encoder();
    Object.defineProperty(exports, "Encoder", { enumerable: true, get: function() {
      return Encoder_ts_1.Encoder;
    } });
    var ExtensionCodec_ts_1 = require_ExtensionCodec();
    Object.defineProperty(exports, "ExtensionCodec", { enumerable: true, get: function() {
      return ExtensionCodec_ts_1.ExtensionCodec;
    } });
    var ExtData_ts_1 = require_ExtData();
    Object.defineProperty(exports, "ExtData", { enumerable: true, get: function() {
      return ExtData_ts_1.ExtData;
    } });
    var timestamp_ts_1 = require_timestamp();
    Object.defineProperty(exports, "EXT_TIMESTAMP", { enumerable: true, get: function() {
      return timestamp_ts_1.EXT_TIMESTAMP;
    } });
    Object.defineProperty(exports, "encodeDateToTimeSpec", { enumerable: true, get: function() {
      return timestamp_ts_1.encodeDateToTimeSpec;
    } });
    Object.defineProperty(exports, "encodeTimeSpecToTimestamp", { enumerable: true, get: function() {
      return timestamp_ts_1.encodeTimeSpecToTimestamp;
    } });
    Object.defineProperty(exports, "decodeTimestampToTimeSpec", { enumerable: true, get: function() {
      return timestamp_ts_1.decodeTimestampToTimeSpec;
    } });
    Object.defineProperty(exports, "encodeTimestampExtension", { enumerable: true, get: function() {
      return timestamp_ts_1.encodeTimestampExtension;
    } });
    Object.defineProperty(exports, "decodeTimestampExtension", { enumerable: true, get: function() {
      return timestamp_ts_1.decodeTimestampExtension;
    } });
  }
});

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/host.js
var ExtensionError = class extends Error {
  kind;
  constructor(message, kind) {
    super(message);
    this.kind = kind;
    this.name = "ExtensionError";
  }
};
async function* readLines(reader) {
  const decoder = new TextDecoder();
  let buffered = "";
  try {
    for (; ; ) {
      const { done, value } = await reader.read();
      if (done)
        break;
      buffered += decoder.decode(value, { stream: true });
      for (let cut = buffered.indexOf("\n"); cut >= 0; cut = buffered.indexOf("\n")) {
        const line = buffered.slice(0, cut);
        buffered = buffered.slice(cut + 1);
        if (line.trim().length > 0)
          yield line;
      }
    }
    buffered += decoder.decode();
    if (buffered.trim().length > 0)
      yield buffered;
  } finally {
    reader.releaseLock();
  }
}
var LineWriter = class {
  writer;
  encoder = new TextEncoder();
  tail = Promise.resolve();
  constructor(writable) {
    this.writer = writable.getWriter();
  }
  write(message) {
    const chunk = this.encoder.encode(`${JSON.stringify(message)}
`);
    const written = this.tail.then(() => this.writer.write(chunk));
    this.tail = written.catch(() => void 0);
    return written;
  }
  async close() {
    await this.tail;
    try {
      await this.writer.close();
    } catch {
      this.writer.releaseLock();
    }
  }
};

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/deno.js
function denoHost() {
  const runtime = globalThis.Deno;
  if (!runtime) {
    throw new ExtensionError("extensions run under deno; no Deno global in this process", "no-runtime");
  }
  return {
    readable: runtime.stdin.readable,
    writable: runtime.stdout.writable,
    exit: (code) => runtime.exit(code)
  };
}

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/message.js
function json(data) {
  return { encoding: "json", data };
}
function asJson(message) {
  return message.encoding === "json" ? message.data : void 0;
}
var CHUNK = 32768;
function toBase64(bytes) {
  let latin1 = "";
  for (let i = 0; i < bytes.length; i += CHUNK) {
    latin1 += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
  }
  return btoa(latin1);
}
function fromBase64(data) {
  const latin1 = atob(data);
  const bytes = new Uint8Array(latin1.length);
  for (let i = 0; i < latin1.length; i++)
    bytes[i] = latin1.charCodeAt(i);
  return bytes;
}
function intoWire(message) {
  if (typeof message === "string")
    return { encoding: "text", data: message };
  if (message instanceof Uint8Array)
    return { encoding: "binary", data: toBase64(message) };
  if (message.encoding === "binary")
    return { encoding: "binary", data: toBase64(message.data) };
  return message;
}
function fromWire(message) {
  if (message.encoding === "binary")
    return { encoding: "binary", data: fromBase64(message.data) };
  return message;
}

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/protocol.js
var EXTENSION_API_VERSION = 1;

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/runtime.js
function describe(value) {
  if (typeof value === "string")
    return value;
  if (value instanceof Error)
    return value.stack ?? `${value.name}: ${value.message}`;
  try {
    return JSON.stringify(value) ?? String(value);
  } catch {
    return String(value);
  }
}
var DeviceImpl = class {
  id;
  runtime;
  name = "";
  active = false;
  connected = false;
  config = {};
  constructor(id, runtime) {
    this.id = id;
    this.runtime = runtime;
  }
  send(message) {
    this.runtime.forward(this.id, message);
  }
};
var ExtensionRuntime = class {
  spec;
  host;
  writer;
  devices_ = /* @__PURE__ */ new Map();
  pending = /* @__PURE__ */ new Map();
  onDevice = /* @__PURE__ */ new Set();
  onMessage = /* @__PURE__ */ new Set();
  onConfig = /* @__PURE__ */ new Set();
  nextRequestId = 1;
  started = false;
  finishing;
  settled;
  helloApi = EXTENSION_API_VERSION;
  helloWebapp = { id: "", name: "", version: "" };
  helloDataDir = "";
  reader;
  constructor(spec, host) {
    this.spec = spec;
    this.host = host;
    this.writer = new LineWriter(host.writable);
  }
  get api() {
    return this.helloApi;
  }
  get webapp() {
    return this.helloWebapp;
  }
  get dataDir() {
    return this.helloDataDir;
  }
  get devices() {
    return [...this.devices_.values()].filter((device) => device.connected);
  }
  device(id) {
    return this.ensure(id);
  }
  broadcast(message) {
    this.forward(void 0, message);
  }
  config(device) {
    const id = typeof device === "string" ? device : device.id;
    return this.devices_.get(id)?.config ?? {};
  }
  on(event, listener) {
    if (event === "device") {
      const fn2 = listener;
      this.onDevice.add(fn2);
      return () => this.onDevice.delete(fn2);
    }
    if (event === "message") {
      const fn2 = listener;
      this.onMessage.add(fn2);
      return () => this.onMessage.delete(fn2);
    }
    const fn = listener;
    this.onConfig.add(fn);
    return () => this.onConfig.delete(fn);
  }
  kv = {
    get: (key) => this.request((id) => ({ t: "kv.get", id, key })).then((value) => value === null ? void 0 : value),
    set: (key, value) => this.request((id) => ({ t: "kv.set", id, key, value })).then(() => void 0),
    delete: (key) => this.request((id) => ({ t: "kv.delete", id, key })).then(() => void 0),
    list: () => this.request((id) => ({ t: "kv.list", id })).then((value) => value ?? [])
  };
  auth = {
    authorize: (url) => this.request((id) => ({ t: "auth.authorize", id, url })).then((value) => String(value))
  };
  log = {
    debug: (...args) => this.log.log("debug", ...args),
    info: (...args) => this.log.log("info", ...args),
    warn: (...args) => this.log.log("warn", ...args),
    error: (...args) => this.log.log("error", ...args),
    log: (level, ...args) => {
      this.emit({ t: "log", level, message: args.map(describe).join(" ") });
    }
  };
  forward(device, message) {
    const wire = intoWire(message);
    this.emit(device === void 0 ? { t: "device.send", message: wire } : { t: "device.send", device, message: wire });
  }
  async run() {
    this.reader = this.host.readable.getReader();
    try {
      for await (const line of readLines(this.reader)) {
        const message = this.parse(line);
        if (!message)
          continue;
        if (message.t === "stop") {
          await this.finish(0);
          return;
        }
        this.dispatch(message);
      }
    } catch (err) {
      await this.finish(1, new ExtensionError(`stdin read failed: ${describe(err)}`, "disconnected"));
      return;
    }
    await this.finish(0);
  }
  ensure(id) {
    const existing = this.devices_.get(id);
    if (existing)
      return existing;
    const fresh = new DeviceImpl(id, this);
    this.devices_.set(id, fresh);
    return fresh;
  }
  parse(line) {
    try {
      return JSON.parse(line);
    } catch (err) {
      this.log.error(`unparseable line from host: ${describe(err)}`);
      return void 0;
    }
  }
  dispatch(message) {
    switch (message.t) {
      case "hello": {
        this.helloApi = message.api;
        this.helloWebapp = message.webapp;
        this.helloDataDir = message.dataDir;
        this.begin();
        return;
      }
      case "device.connected": {
        const device = this.ensure(message.device);
        device.name = message.name;
        device.config = { ...message.config };
        device.active = message.active;
        device.connected = true;
        this.announce({ type: "connected", device });
        return;
      }
      case "device.disconnected": {
        const device = this.devices_.get(message.device);
        if (!device)
          return;
        device.connected = false;
        device.active = false;
        this.announce({ type: "disconnected", device });
        return;
      }
      case "device.active": {
        const device = this.ensure(message.device);
        device.active = message.active;
        this.announce({ type: "active", device });
        return;
      }
      case "device.message": {
        const device = this.ensure(message.device);
        const forwarded = this.guard(() => fromWire(message.message));
        if (!forwarded)
          return;
        for (const listener of [...this.onMessage])
          this.guard(() => listener(device, forwarded));
        return;
      }
      case "config.changed": {
        const device = this.ensure(message.device);
        const next = { ...device.config };
        if (message.value === null)
          delete next[message.key];
        else
          next[message.key] = message.value;
        device.config = next;
        for (const listener of [...this.onConfig]) {
          this.guard(() => listener(device, message.key, message.value));
        }
        return;
      }
      case "reply": {
        const waiting = this.pending.get(message.id);
        if (!waiting)
          return;
        this.pending.delete(message.id);
        if (message.ok)
          waiting.resolve(message.value);
        else
          waiting.reject(new ExtensionError(message.error, "host-error"));
        return;
      }
    }
  }
  begin() {
    if (this.started)
      return;
    this.started = true;
    let starting;
    try {
      starting = this.spec.start(this);
    } catch (err) {
      this.abortStart(err);
      return;
    }
    void Promise.resolve(starting).then(() => this.emit({ t: "ready" }), (err) => this.abortStart(err));
  }
  abortStart(err) {
    this.log.error(`start failed: ${describe(err)}`);
    void this.finish(1, new ExtensionError(describe(err), "host-error"));
  }
  announce(event) {
    for (const listener of [...this.onDevice])
      this.guard(() => listener(event));
  }
  guard(run) {
    try {
      return run();
    } catch (err) {
      this.log.error(describe(err));
      return void 0;
    }
  }
  emit(message) {
    this.writer.write(message).catch((err) => {
      void this.finish(1, new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
    });
  }
  request(build) {
    if (this.settled) {
      const advice = "kv and auth cannot be reached once shutdown has begun, so persist eagerly rather than from stop";
      return Promise.reject(new ExtensionError(`${this.settled.message}; ${advice}`, this.settled.kind));
    }
    const id = String(this.nextRequestId++);
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.writer.write(build(id)).catch((err) => {
        if (!this.pending.delete(id))
          return;
        reject(new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
      });
    });
  }
  finish(code, reason) {
    this.finishing ??= this.shutdown(code, reason);
    return this.finishing;
  }
  async shutdown(code, reason) {
    const failure = reason ?? new ExtensionError("the host closed the connection", "disconnected");
    this.settled = failure;
    await this.reader?.cancel().catch(() => void 0);
    for (const waiting of [...this.pending.values()])
      waiting.reject(failure);
    this.pending.clear();
    try {
      await this.spec.stop?.();
    } catch (err) {
      await this.writer.write({ t: "log", level: "error", message: `stop failed: ${describe(err)}` }).catch(() => void 0);
    }
    await this.writer.close();
    this.host.exit(code);
  }
};

// ../../node_modules/.bun/@bridgething+extension@0.12.1+7524df1edfed9f02/node_modules/@bridgething/extension/dist/index.js
function defineExtension(spec, host = denoHost()) {
  return new ExtensionRuntime(spec, host).run();
}

// extension/archive/bplist.ts
function isBplist(b) {
  return b.length > 40 && new TextDecoder().decode(b.subarray(0, 8)) === "bplist00";
}
function parseBplist(b) {
  const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
  const t = b.length - 32;
  const offSize = b[t + 6];
  const refSize = b[t + 7];
  const numObjects = Number(dv.getBigUint64(t + 8));
  const top = Number(dv.getBigUint64(t + 16));
  const tableOff = Number(dv.getBigUint64(t + 24));
  const uint = (at, n) => {
    let v = 0;
    for (let i = 0; i < n; i++) v = v * 256 + b[at + i];
    return v;
  };
  const offsets = Array.from({ length: numObjects }, (_, i) => uint(tableOff + i * offSize, offSize));
  const seen = /* @__PURE__ */ new Set();
  const read = (ref) => {
    if (seen.has(ref)) throw new Error("bplist cycle");
    seen.add(ref);
    try {
      return readAt(offsets[ref]);
    } finally {
      seen.delete(ref);
    }
  };
  const len = (at) => {
    const lo = b[at] & 15;
    if (lo !== 15) return [lo, at + 1];
    const n = 1 << (b[at + 1] & 15);
    return [uint(at + 2, n), at + 2 + n];
  };
  const readAt = (at) => {
    const m = b[at];
    const hi = m >> 4;
    switch (hi) {
      case 0:
        return m === 9 ? true : m === 8 ? false : null;
      case 1: {
        const n = 1 << (m & 15);
        if (n === 8) return Number(dv.getBigInt64(at + 1));
        return uint(at + 1, n);
      }
      case 2:
        return (m & 15) === 2 ? dv.getFloat32(at + 1) : dv.getFloat64(at + 1);
      case 3: {
        return new Date((dv.getFloat64(at + 1) + 978307200) * 1e3);
      }
      case 4: {
        const [n, s] = len(at);
        return b.subarray(s, s + n);
      }
      case 5: {
        const [n, s] = len(at);
        return String.fromCharCode(...b.subarray(s, s + n));
      }
      case 6: {
        const [n, s] = len(at);
        let out = "";
        for (let i = 0; i < n; i++) out += String.fromCharCode(dv.getUint16(s + 2 * i));
        return out;
      }
      case 8:
        return uint(at + 1, (m & 15) + 1);
      case 10: {
        const [n, s] = len(at);
        return Array.from({ length: n }, (_, i) => read(uint(s + i * refSize, refSize)));
      }
      case 13: {
        const [n, s] = len(at);
        const o = {};
        for (let i = 0; i < n; i++) {
          const k = read(uint(s + i * refSize, refSize));
          o[String(k)] = read(uint(s + (n + i) * refSize, refSize));
        }
        return o;
      }
      default:
        throw new Error(`bplist marker ${m.toString(16)}`);
    }
  };
  return read(top);
}

// extension/archive/proto.ts
var Msg = class _Msg {
  constructor(bytes) {
    this.bytes = bytes;
    this.fields = parseFields(bytes);
  }
  bytes;
  fields;
  // lenient sub-message: wrong wire type or garbage yields an empty message
  static from(f) {
    if (!f || f.wt !== 2) return EMPTY_MSG;
    try {
      return new _Msg(f.raw);
    } catch {
      return EMPTY_MSG;
    }
  }
  all(no) {
    return this.fields.filter((f) => f.no === no);
  }
  get(no) {
    for (let i = this.fields.length - 1; i >= 0; i--) if (this.fields[i].no === no) return this.fields[i];
    return void 0;
  }
  has(no) {
    return this.get(no) !== void 0;
  }
  msg(no) {
    const f = this.get(no);
    return f && f.wt === 2 ? _Msg.from(f) : void 0;
  }
  msgs(no) {
    return this.all(no).filter((f) => f.wt === 2).map((f) => _Msg.from(f));
  }
  int(no, def = 0) {
    const f = this.get(no);
    return f && f.wt === 0 ? f.v : def;
  }
  // signed varint stored as two's complement 64-bit
  sint(no, def = 0) {
    const v = this.int(no, def);
    return v >= 2 ** 63 ? v - 2 ** 64 : v;
  }
  float(no, def = 0) {
    const f = this.get(no);
    if (!f) return def;
    const dv = new DataView(f.raw.buffer, f.raw.byteOffset, f.raw.byteLength);
    if (f.wt === 5) return dv.getFloat32(0, true);
    if (f.wt === 1) return dv.getFloat64(0, true);
    if (f.wt === 0) return f.v;
    return def;
  }
  bool(no, def = false) {
    const f = this.get(no);
    return f ? f.v !== 0 : def;
  }
  bytesOf(no) {
    const f = this.get(no);
    return f && f.wt === 2 ? f.raw : void 0;
  }
  str(no) {
    const b = this.bytesOf(no);
    return b ? new TextDecoder().decode(b) : void 0;
  }
};
function parseFields(b) {
  const out = [];
  let i = 0;
  const varint = () => {
    let r = 0;
    let s = 1;
    for (; ; ) {
      if (i >= b.length) throw new Error("truncated varint");
      const c = b[i++];
      r += (c & 127) * s;
      s *= 128;
      if (c < 128) return r;
    }
  };
  while (i < b.length) {
    const key = varint();
    const wt = key % 8;
    const no = Math.floor(key / 8);
    if (no === 0) throw new Error("field 0");
    if (wt === 0) out.push({ no, wt, v: varint(), raw: EMPTY });
    else if (wt === 1 || wt === 5) {
      const n = wt === 1 ? 8 : 4;
      if (i + n > b.length) throw new Error("truncated fixed");
      out.push({ no, wt, v: 0, raw: b.subarray(i, i + n) });
      i += n;
    } else if (wt === 2) {
      const n = varint();
      if (i + n > b.length) throw new Error("truncated bytes");
      out.push({ no, wt, v: 0, raw: b.subarray(i, i + n) });
      i += n;
    } else throw new Error(`wire type ${wt}`);
  }
  return out;
}
var EMPTY = new Uint8Array(0);
var EMPTY_MSG = new Msg(EMPTY);
var hex = (b) => Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
function base64(b) {
  let s = "";
  for (let i = 0; i < b.length; i += 32768) s += String.fromCharCode(...b.subarray(i, i + 32768));
  return btoa(s);
}
function f16(bits) {
  const s = bits & 32768 ? -1 : 1;
  const e = bits >> 10 & 31;
  const m = bits & 1023;
  if (e === 0) return s * m * 2 ** -24;
  if (e === 31) return m ? NaN : s * Infinity;
  return s * (1 + m / 1024) * 2 ** (e - 15);
}

// extension/archive/cff.ts
function readIndex(b, at) {
  const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
  const count = dv.getUint16(at);
  if (!count) return [[], at + 2];
  const os = b[at + 2];
  const off = (i) => {
    let v = 0;
    for (let k = 0; k < os; k++) v = v * 256 + b[at + 3 + i * os + k];
    return v;
  };
  const base = at + 2 + (count + 1) * os;
  const items = [];
  for (let i = 0; i < count; i++) items.push(b.subarray(base + off(i), base + off(i + 1)));
  return [items, base + off(count)];
}
function readDict(d) {
  const out = /* @__PURE__ */ new Map();
  let ops = [];
  for (let i = 0; i < d.length; ) {
    const v = d[i];
    if (v <= 21) {
      const key = v === 12 ? 1200 + d[i + 1] : v;
      i += v === 12 ? 2 : 1;
      out.set(key, ops);
      ops = [];
    } else if (v === 28) {
      ops.push(d[i + 1] << 24 >> 16 | d[i + 2]);
      i += 3;
    } else if (v === 29) {
      ops.push(d[i + 1] << 24 | d[i + 2] << 16 | d[i + 3] << 8 | d[i + 4]);
      i += 5;
    } else if (v === 30) {
      let s = "";
      i++;
      outer: for (; ; ) {
        const byte = d[i++];
        for (const nib of [byte >> 4, byte & 15]) {
          if (nib === 15) break outer;
          s += "0123456789.EE?-"[nib] + (nib === 12 ? "-" : "");
        }
      }
      ops.push(parseFloat(s));
    } else if (v >= 32 && v <= 246) ops.push(v - 139), i++;
    else if (v >= 247 && v <= 250) ops.push((v - 247) * 256 + d[i + 1] + 108), i += 2;
    else if (v >= 251 && v <= 254) ops.push(-(v - 251) * 256 - d[i + 1] - 108), i += 2;
    else i++;
  }
  return out;
}
var bias = (n) => n < 1240 ? 107 : n < 33900 ? 1131 : 32768;
function parseCFF(b) {
  const hdr = b[2];
  const [, a1] = readIndex(b, hdr);
  const [tops, a2] = readIndex(b, a1);
  const [, a3] = readIndex(b, a2);
  const [gsubrs] = readIndex(b, a3);
  const top = readDict(tops[0] ?? new Uint8Array());
  const [charstrings] = readIndex(b, top.get(17)?.[0] ?? 0);
  const fm = top.get(1207);
  const unitsPerEm = fm?.[0] ? Math.round(1 / fm[0]) : 1e3;
  const privSubrs = (p) => {
    if (!p || p.length < 2) return [];
    const pd = readDict(b.subarray(p[1], p[1] + p[0]));
    const so = pd.get(19)?.[0];
    return so ? readIndex(b, p[1] + so)[0] : [];
  };
  let subrsFor;
  const fdArrayOff = top.get(1236)?.[0];
  if (fdArrayOff !== void 0) {
    const [fds] = readIndex(b, fdArrayOff);
    const fdSubrs = fds.map((fd) => privSubrs(readDict(fd).get(18)));
    const sel = top.get(1237)?.[0] ?? 0;
    const fmt = b[sel];
    const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
    subrsFor = (gid) => {
      if (fmt === 0) return fdSubrs[b[sel + 1 + gid]] ?? [];
      const n = dv.getUint16(sel + 1);
      for (let i = 0; i < n; i++) {
        const first = dv.getUint16(sel + 3 + 3 * i);
        const next = dv.getUint16(sel + 3 + 3 * (i + 1));
        if (gid >= first && gid < next) return fdSubrs[b[sel + 5 + 3 * i]] ?? [];
      }
      return [];
    };
  } else {
    const s = privSubrs(top.get(18));
    subrsFor = () => s;
  }
  const glyphPath = (gid) => {
    const cs = charstrings[gid];
    if (!cs) return "";
    const subrs = subrsFor(gid);
    const r = (v) => +v.toFixed(1);
    let d = "";
    let x = 0;
    let y = 0;
    let open = false;
    let stems = 0;
    let widthDone = false;
    const st = [];
    const move = (dx, dy) => {
      if (open) d += "Z";
      x += dx;
      y += dy;
      d += `M${r(x)} ${r(y)}`;
      open = true;
    };
    const line = (dx, dy) => {
      x += dx;
      y += dy;
      d += `L${r(x)} ${r(y)}`;
    };
    const curve = (a, b2, c, e, f, g) => {
      const x1 = x + a;
      const y1 = y + b2;
      const x2 = x1 + c;
      const y2 = y1 + e;
      x = x2 + f;
      y = y2 + g;
      d += `C${r(x1)} ${r(y1)} ${r(x2)} ${r(y2)} ${r(x)} ${r(y)}`;
    };
    const width = (even) => {
      if (!widthDone && st.length % 2 === (even ? 1 : 0)) st.shift();
      widthDone = true;
    };
    let depth = 0;
    const run = (code) => {
      if (++depth > 10) return true;
      for (let i = 0; i < code.length; ) {
        const v = code[i];
        if (v >= 32 || v === 28) {
          if (v === 28) st.push(code[i + 1] << 24 >> 16 | code[i + 2]), i += 3;
          else if (v <= 246) st.push(v - 139), i++;
          else if (v <= 250) st.push((v - 247) * 256 + code[i + 1] + 108), i += 2;
          else if (v <= 254) st.push(-(v - 251) * 256 - code[i + 1] - 108), i += 2;
          else st.push((code[i + 1] << 24 | code[i + 2] << 16 | code[i + 3] << 8 | code[i + 4]) / 65536), i += 5;
          continue;
        }
        i++;
        switch (v) {
          case 1:
          case 3:
          case 18:
          case 23:
            width(true);
            stems += st.length >> 1;
            st.length = 0;
            break;
          case 19:
          case 20:
            width(true);
            stems += st.length >> 1;
            st.length = 0;
            i += stems + 7 >> 3;
            break;
          case 21:
            width(true);
            move(st[0], st[1]);
            st.length = 0;
            break;
          case 22:
            width(false);
            move(st[0], 0);
            st.length = 0;
            break;
          case 4:
            width(false);
            move(0, st[0]);
            st.length = 0;
            break;
          case 5:
            for (let k = 0; k + 1 < st.length; k += 2) line(st[k], st[k + 1]);
            st.length = 0;
            break;
          case 6:
          case 7: {
            let h = v === 6;
            for (const n of st) h ? line(n, 0) : line(0, n), h = !h;
            st.length = 0;
            break;
          }
          case 8:
            for (let k = 0; k + 5 < st.length; k += 6) curve(st[k], st[k + 1], st[k + 2], st[k + 3], st[k + 4], st[k + 5]);
            st.length = 0;
            break;
          case 24: {
            let k = 0;
            for (; k + 7 < st.length; k += 6) curve(st[k], st[k + 1], st[k + 2], st[k + 3], st[k + 4], st[k + 5]);
            line(st[k], st[k + 1]);
            st.length = 0;
            break;
          }
          case 25: {
            let k = 0;
            for (; k + 7 < st.length; k += 2) line(st[k], st[k + 1]);
            curve(st[k], st[k + 1], st[k + 2], st[k + 3], st[k + 4], st[k + 5]);
            st.length = 0;
            break;
          }
          case 26:
          case 27: {
            let k = 0;
            let e = st.length % 2 ? st[k++] : 0;
            for (; k + 3 < st.length; k += 4) {
              if (v === 26) curve(e, st[k], st[k + 1], st[k + 2], 0, st[k + 3]);
              else curve(st[k], e, st[k + 1], st[k + 2], st[k + 3], 0);
              e = 0;
            }
            st.length = 0;
            break;
          }
          case 30:
          case 31: {
            let h = v === 31;
            for (let k = 0; k + 3 < st.length; k += 4) {
              const last = k + 5 === st.length ? st[k + 4] : 0;
              if (h) curve(st[k], 0, st[k + 1], st[k + 2], last, st[k + 3]);
              else curve(0, st[k], st[k + 1], st[k + 2], st[k + 3], last);
              h = !h;
            }
            st.length = 0;
            break;
          }
          case 10:
          case 29: {
            const set = v === 10 ? subrs : gsubrs;
            const n = st.pop() + bias(set.length);
            const sub = set[n];
            if (sub && run(sub)) return true;
            break;
          }
          case 11:
            depth--;
            return false;
          case 14:
            width(true);
            if (open) d += "Z";
            open = false;
            return true;
          case 12: {
            const e = code[i++];
            const s = st.splice(0);
            if (e === 35) curve(s[0], s[1], s[2], s[3], s[4], s[5]), curve(s[6], s[7], s[8], s[9], s[10], s[11]);
            else if (e === 34) curve(s[0], 0, s[1], s[2], s[3], 0), curve(s[4], 0, s[5], -s[2], s[6], 0);
            else if (e === 36) curve(s[0], s[1], s[2], s[3], s[4], 0), curve(s[5], 0, s[6], s[7], s[8], -(s[1] + s[3] + s[7]));
            else if (e === 37) {
              const [sx, sy] = [x, y];
              const dx = s[0] + s[2] + s[4] + s[6] + s[8];
              const dy = s[1] + s[3] + s[5] + s[7] + s[9];
              curve(s[0], s[1], s[2], s[3], s[4], s[5]);
              const horiz = Math.abs(dx) > Math.abs(dy);
              curve(s[6], s[7], s[8], s[9], horiz ? s[10] : sx - x - s[6] - s[8], horiz ? sy - y - s[7] - s[9] : s[10]);
            }
            break;
          }
          default:
            st.length = 0;
        }
      }
      depth--;
      return false;
    };
    try {
      run(cs);
    } catch {
      return "";
    }
    if (open) d += "Z";
    return d;
  };
  return { unitsPerEm, numGlyphs: charstrings.length, glyphPath };
}

// extension/archive/sfnt.ts
function parseFont(bytes, name = "", coords) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (bytes[0] === 1 && bytes[1] === 0 && bytes[2] === 4) {
    const c = parseCFF(bytes);
    const cache2 = /* @__PURE__ */ new Map();
    return { name, bytes, unitsPerEm: c.unitsPerEm, numGlyphs: c.numGlyphs, charFor: () => void 0, glyphPath: (g) => cache2.get(g) ?? (cache2.set(g, c.glyphPath(g)), cache2.get(g)) };
  }
  const n = dv.getUint16(4);
  const tables = /* @__PURE__ */ new Map();
  for (let i = 0; i < n; i++) {
    const r = 12 + 16 * i;
    const tag = String.fromCharCode(...bytes.subarray(r, r + 4));
    tables.set(tag, [dv.getUint32(r + 8), dv.getUint32(r + 12)]);
  }
  const head = tables.get("head");
  const maxp = tables.get("maxp");
  if (!head || !maxp) throw new Error("sfnt missing head/maxp");
  const unitsPerEm = dv.getUint16(head[0] + 18);
  const longLoca = dv.getInt16(head[0] + 50) === 1;
  const numGlyphs = dv.getUint16(maxp[0] + 4);
  const loca = tables.get("loca");
  const glyf = tables.get("glyf");
  const cache = /* @__PURE__ */ new Map();
  const rev = reverseCmap(bytes, dv, tables.get("cmap"));
  const version = nameString(bytes, dv, tables.get("name"), 3);
  const norm = coords ? normalizedCoords(dv, tables, coords) : void 0;
  const gvar = norm?.some((v) => v) ? tables.get("gvar") : void 0;
  const cffT = tables.get("CFF ");
  if (!glyf && cffT) {
    const c = parseCFF(bytes.subarray(cffT[0], cffT[0] + cffT[1]));
    return { name, bytes, unitsPerEm, numGlyphs, charFor: (g) => rev.get(g), glyphPath: (g) => cache.get(g) ?? (cache.set(g, c.glyphPath(g)), cache.get(g)) };
  }
  const glyphRange = (gid) => {
    if (!loca || !glyf || gid < 0 || gid >= numGlyphs) return void 0;
    const at = (i) => longLoca ? dv.getUint32(loca[0] + 4 * i) : dv.getUint16(loca[0] + 2 * i) * 2;
    const s = at(gid);
    const e = at(gid + 1);
    return e > s ? [glyf[0] + s, glyf[0] + e] : void 0;
  };
  const contours = (gid, depth) => {
    const r = glyphRange(gid);
    if (!r || depth > 8) return [];
    let p = r[0];
    const nc = dv.getInt16(p);
    p += 10;
    if (nc >= 0) {
      const ends = [];
      for (let i = 0; i < nc; i++, p += 2) ends.push(dv.getUint16(p));
      const np = nc ? ends[nc - 1] + 1 : 0;
      p += 2 + dv.getUint16(p);
      const flags = [];
      while (flags.length < np) {
        const f = bytes[p++];
        flags.push(f);
        if (f & 8) for (let k = bytes[p++]; k > 0; k--) flags.push(f);
      }
      const coord = (short, same) => {
        const out3 = [];
        let v = 0;
        for (const f of flags) {
          if (f & short) {
            const d = bytes[p++];
            v += f & same ? d : -d;
          } else if (!(f & same)) {
            v += dv.getInt16(p);
            p += 2;
          }
          out3.push(v);
        }
        return out3;
      };
      const xs = coord(2, 16);
      const ys = coord(4, 32);
      if (gvar && norm) applyGvar(dv, gvar[0], gid, norm, xs, ys, ends);
      const out2 = [];
      let s = 0;
      for (const e of ends) {
        const c = [];
        for (let i = s; i <= e; i++) c.push({ x: xs[i], y: ys[i], on: (flags[i] & 1) === 1 });
        out2.push(c);
        s = e + 1;
      }
      return out2;
    }
    const out = [];
    for (; ; ) {
      const f = dv.getUint16(p);
      const g = dv.getUint16(p + 2);
      p += 4;
      let dx = 0;
      let dy = 0;
      if (f & 1) {
        dx = dv.getInt16(p);
        dy = dv.getInt16(p + 2);
        p += 4;
      } else {
        dx = dv.getInt8(p);
        dy = dv.getInt8(p + 1);
        p += 2;
      }
      let [a, b, c, d] = [1, 0, 0, 1];
      const f2 = (o) => dv.getInt16(o) / 16384;
      if (f & 8) {
        a = d = f2(p);
        p += 2;
      } else if (f & 64) {
        a = f2(p);
        d = f2(p + 2);
        p += 4;
      } else if (f & 128) {
        [a, b, c, d] = [f2(p), f2(p + 2), f2(p + 4), f2(p + 6)];
        p += 8;
      }
      if (!(f & 2)) dx = dy = 0;
      for (const cont of contours(g, depth + 1))
        out.push(cont.map((q) => ({ x: a * q.x + c * q.y + dx, y: b * q.x + d * q.y + dy, on: q.on })));
      if (!(f & 32)) break;
    }
    return out;
  };
  const toPath = (cs) => {
    const r = (v) => +v.toFixed(1);
    let d = "";
    for (const c of cs) {
      if (!c.length) continue;
      let start2 = c.findIndex((q) => q.on);
      const pts = start2 < 0 ? c : [...c.slice(start2), ...c.slice(0, start2)];
      const first = start2 < 0 ? { x: (c[0].x + c[1 % c.length].x) / 2, y: (c[0].y + c[1 % c.length].y) / 2, on: true } : pts[0];
      d += `M${r(first.x)} ${r(first.y)}`;
      const seq = start2 < 0 ? [...pts, pts[0]] : [...pts.slice(1), pts[0]];
      let ctrl;
      for (const q of seq) {
        if (q.on) {
          d += ctrl ? `Q${r(ctrl.x)} ${r(ctrl.y)} ${r(q.x)} ${r(q.y)}` : `L${r(q.x)} ${r(q.y)}`;
          ctrl = void 0;
        } else {
          if (ctrl) {
            const mx = (ctrl.x + q.x) / 2;
            const my = (ctrl.y + q.y) / 2;
            d += `Q${r(ctrl.x)} ${r(ctrl.y)} ${r(mx)} ${r(my)}`;
          }
          ctrl = q;
        }
      }
      if (ctrl) d += `Q${r(ctrl.x)} ${r(ctrl.y)} ${r(first.x)} ${r(first.y)}`;
      d += "Z";
    }
    return d;
  };
  return {
    name,
    version,
    unitsPerEm,
    numGlyphs,
    bytes,
    glyphPath(gid) {
      let d = cache.get(gid);
      if (d === void 0) {
        try {
          d = toPath(contours(gid, 0));
        } catch {
          d = "";
        }
        cache.set(gid, d);
      }
      return d;
    },
    charFor: (gid) => rev.get(gid)
  };
}
function nameString(bytes, dv, t, id) {
  if (!t) return void 0;
  const count = dv.getUint16(t[0] + 2);
  const str = t[0] + dv.getUint16(t[0] + 4);
  for (let i = 0; i < count; i++) {
    const r = t[0] + 6 + 12 * i;
    if (dv.getUint16(r + 6) !== id) continue;
    const [pid, len, off] = [dv.getUint16(r), dv.getUint16(r + 8), str + dv.getUint16(r + 10)];
    if (pid === 3 || pid === 0) {
      let out = "";
      for (let k = 0; k < len; k += 2) out += String.fromCharCode(dv.getUint16(off + k));
      return out;
    }
    if (pid === 1) return String.fromCharCode(...bytes.subarray(off, off + len));
  }
  return void 0;
}
function normalizedCoords(dv, tables, coords) {
  const fvar = tables.get("fvar");
  if (!fvar) return void 0;
  const base = fvar[0];
  const axesOff = base + dv.getUint16(base + 4);
  const count = dv.getUint16(base + 8);
  const size = dv.getUint16(base + 10);
  const fx = (o) => dv.getInt32(o) / 65536;
  const out = [];
  for (let i = 0; i < count; i++) {
    const a = axesOff + i * size;
    const tag = String.fromCharCode(dv.getUint8(a), dv.getUint8(a + 1), dv.getUint8(a + 2), dv.getUint8(a + 3));
    const [min, def, max] = [fx(a + 4), fx(a + 8), fx(a + 12)];
    const v = Math.min(max, Math.max(min, coords[tag] ?? def));
    out.push(v < def ? def === min ? 0 : (v - def) / (def - min) : v > def ? max === def ? 0 : (v - def) / (max - def) : 0);
  }
  const avar = tables.get("avar");
  if (avar) {
    let p = avar[0] + 8;
    for (let i = 0; i < Math.min(count, dv.getUint16(avar[0] + 6)); i++) {
      const n = dv.getUint16(p);
      const maps = [];
      for (let k = 0; k < n; k++) maps.push([dv.getInt16(p + 2 + 4 * k) / 16384, dv.getInt16(p + 4 + 4 * k) / 16384]);
      p += 2 + 4 * n;
      const v = out[i];
      for (let k = 1; k < maps.length; k++) {
        const [a0, b0] = maps[k - 1];
        const [a1, b1] = maps[k];
        if (v <= a1) {
          out[i] = a1 === a0 ? b0 : b0 + (v - a0) * (b1 - b0) / (a1 - a0);
          break;
        }
      }
    }
  }
  return out;
}
function applyGvar(dv, base, gid, norm, xs, ys, ends) {
  const axisCount = dv.getUint16(base + 4);
  const sharedCount = dv.getUint16(base + 6);
  const sharedOff = base + dv.getUint32(base + 8);
  const glyphCount = dv.getUint16(base + 12);
  const longOffsets = dv.getUint16(base + 14) & 1;
  const dataOff = base + dv.getUint32(base + 16);
  if (gid >= glyphCount) return;
  const off = (i) => longOffsets ? dv.getUint32(base + 20 + 4 * i) : dv.getUint16(base + 20 + 2 * i) * 2;
  const start2 = dataOff + off(gid);
  if (off(gid + 1) <= off(gid)) return;
  const np = xs.length;
  const total = np + 4;
  const tuple = (o) => Array.from({ length: axisCount }, (_, i) => dv.getInt16(o + 2 * i) / 16384);
  const shared = Array.from({ length: sharedCount }, (_, i) => tuple(sharedOff + 2 * axisCount * i));
  let p = 0;
  const readPoints = () => {
    let n = dv.getUint8(p++);
    if (n & 128) n = (n & 127) << 8 | dv.getUint8(p++);
    if (!n) return void 0;
    const pts = [];
    let last = 0;
    while (pts.length < n) {
      const c = dv.getUint8(p++);
      const words = c & 128;
      for (let k = 0; k <= (c & 127) && pts.length < n; k++) {
        last += words ? dv.getUint16((p += 2) - 2) : dv.getUint8(p++);
        pts.push(last);
      }
    }
    return pts;
  };
  const readDeltas = (n) => {
    const out = [];
    while (out.length < n) {
      const c = dv.getUint8(p++);
      const cnt = (c & 63) + 1;
      for (let k = 0; k < cnt && out.length < n; k++) {
        if (c & 128) out.push(0);
        else if (c & 64) out.push(dv.getInt16((p += 2) - 2));
        else out.push(dv.getInt8(p++));
      }
    }
    return out;
  };
  const header = dv.getUint16(start2);
  const count = header & 4095;
  p = start2 + dv.getUint16(start2 + 2);
  const sharedPts = header & 32768 ? readPoints() : void 0;
  let h = start2 + 4;
  const dx = new Float64Array(np);
  const dy = new Float64Array(np);
  for (let t = 0; t < count; t++) {
    const size = dv.getUint16(h);
    const idx = dv.getUint16(h + 2);
    h += 4;
    let peak;
    if (idx & 32768) {
      peak = tuple(h);
      h += 2 * axisCount;
    } else peak = shared[idx & 4095] ?? [];
    let lo;
    let hi;
    if (idx & 16384) {
      lo = tuple(h);
      hi = tuple(h + 2 * axisCount);
      h += 4 * axisCount;
    }
    const dataStart = p;
    let scalar = 1;
    for (let i = 0; i < axisCount && scalar; i++) {
      const pk = peak[i] ?? 0;
      const v = norm[i] ?? 0;
      if (!pk) continue;
      const a = lo ? lo[i] : Math.min(0, pk);
      const b = hi ? hi[i] : Math.max(0, pk);
      if (v < a || v > b) scalar = 0;
      else if (v === pk) continue;
      else scalar *= v < pk ? pk === a ? 1 : (v - a) / (pk - a) : pk === b ? 1 : (b - v) / (b - pk);
    }
    if (scalar) {
      const pts = idx & 8192 ? readPoints() : sharedPts;
      const n = pts ? pts.length : total;
      const xd = readDeltas(n);
      const yd = readDeltas(n);
      const tx = new Float64Array(np);
      const ty = new Float64Array(np);
      const touched = new Uint8Array(np);
      for (let k = 0; k < n; k++) {
        const pi = pts ? pts[k] : k;
        if (pi >= np) continue;
        tx[pi] = xd[k];
        ty[pi] = yd[k];
        touched[pi] = 1;
      }
      if (pts) iup(xs, ys, ends, tx, ty, touched);
      for (let i = 0; i < np; i++) {
        dx[i] = dx[i] + tx[i] * scalar;
        dy[i] = dy[i] + ty[i] * scalar;
      }
    }
    p = dataStart + size;
  }
  for (let i = 0; i < np; i++) {
    xs[i] = xs[i] + dx[i];
    ys[i] = ys[i] + dy[i];
  }
}
function iup(xs, ys, ends, dx, dy, touched) {
  let s = 0;
  for (const e of ends) {
    const idx = [];
    for (let i = s; i <= e; i++) if (touched[i]) idx.push(i);
    if (idx.length) {
      for (let k = 0; k < idx.length; k++) {
        const a = idx[k];
        const b = idx[(k + 1) % idx.length];
        for (let i = a + 1; ; i++) {
          const j = i > e ? s + (i - e - 1) : i;
          if (j === b) break;
          for (const [c, d] of [[xs, dx], [ys, dy]]) {
            const [ca, cb] = [c[a], c[b]];
            const [da, db] = [d[a], d[b]];
            const v = c[j];
            if (ca === cb) d[j] = da === db ? da : 0;
            else if (v <= Math.min(ca, cb)) d[j] = ca < cb ? da : db;
            else if (v >= Math.max(ca, cb)) d[j] = ca > cb ? da : db;
            else d[j] = da + (v - ca) * (db - da) / (cb - ca);
          }
          if (i > e + (e - s + 1)) break;
        }
      }
    }
    s = e + 1;
  }
}
function reverseCmap(bytes, dv, t) {
  const out = /* @__PURE__ */ new Map();
  if (!t) return out;
  const base = t[0];
  const n = dv.getUint16(base + 2);
  const subs = [];
  for (let i = 0; i < n; i++)
    subs.push({ pid: dv.getUint16(base + 4 + 8 * i), eid: dv.getUint16(base + 6 + 8 * i), off: base + dv.getUint32(base + 8 + 8 * i) });
  subs.sort((a, b) => Number(b.pid === 0 || b.pid === 3) - Number(a.pid === 0 || a.pid === 3));
  for (const s of subs) {
    const mac = s.pid === 1;
    const put = (code, gid) => {
      if (gid && !out.has(gid)) out.set(gid, mac ? macRoman(code) : String.fromCodePoint(code));
    };
    const fmt = dv.getUint16(s.off);
    if (fmt === 0) for (let c = 0; c < 256; c++) put(c, bytes[s.off + 6 + c]);
    else if (fmt === 6) {
      const first = dv.getUint16(s.off + 6);
      const count = dv.getUint16(s.off + 8);
      for (let i = 0; i < count; i++) put(first + i, dv.getUint16(s.off + 10 + 2 * i));
    } else if (fmt === 4) {
      const segs = dv.getUint16(s.off + 6) / 2;
      const ends = s.off + 14;
      const starts = ends + 2 * segs + 2;
      const deltas = starts + 2 * segs;
      const ranges = deltas + 2 * segs;
      for (let i = 0; i < segs; i++) {
        const e = dv.getUint16(ends + 2 * i);
        const st = dv.getUint16(starts + 2 * i);
        const delta = dv.getInt16(deltas + 2 * i);
        const ro = dv.getUint16(ranges + 2 * i);
        for (let c = st; c <= e && c !== 65535; c++) {
          let g;
          if (!ro) g = c + delta & 65535;
          else {
            const gi = ranges + 2 * i + ro + 2 * (c - st);
            g = dv.getUint16(gi);
            if (g) g = g + delta & 65535;
          }
          put(c, g);
        }
      }
    } else if (fmt === 12) {
      const groups = dv.getUint32(s.off + 12);
      for (let i = 0; i < groups; i++) {
        const g = s.off + 16 + 12 * i;
        const sc = dv.getUint32(g);
        const ec = dv.getUint32(g + 4);
        const sg = dv.getUint32(g + 8);
        for (let c = sc; c <= ec && c - sc < 65536; c++) put(c, sg + c - sc);
      }
    }
  }
  return out;
}
var MAC_HIGH = "\xC4\xC5\xC7\xC9\xD1\xD6\xDC\xE1\xE0\xE2\xE4\xE3\xE5\xE7\xE9\xE8\xEA\xEB\xED\xEC\xEE\xEF\xF1\xF3\xF2\xF4\xF6\xF5\xFA\xF9\xFB\xFC\u2020\xB0\xA2\xA3\xA7\u2022\xB6\xDF\xAE\xA9\u2122\xB4\xA8\u2260\xC6\xD8\u221E\xB1\u2264\u2265\xA5\xB5\u2202\u2211\u220F\u03C0\u222B\xAA\xBA\u03A9\xE6\xF8\xBF\xA1\xAC\u221A\u0192\u2248\u2206\xAB\xBB\u2026 \xC0\xC3\xD5\u0152\u0153\u2013\u2014\u201C\u201D\u2018\u2019\xF7\u25CA\xFF\u0178\u2044\u20AC\u2039\u203A\uFB01\uFB02\u2021\xB7\u201A\u201E\u2030\xC2\xCA\xC1\xCB\xC8\xCD\xCE\xCF\xCC\xD3\xD4\xD2\xDA\xDB\xD9\u0131\u02C6\u02DC\xAF\u02D8\u02D9\u02DA\xB8\u02DD\u02DB\u02C7";
var macRoman = (c) => c < 128 ? String.fromCharCode(c) : MAC_HIGH[c - 128] ?? "\uFFFD";

// extension/archive/sysfont.ts
import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
var FONT_DIRS = ["/System/Library/Fonts", "/Library/Fonts"];
var IOS_TO_MACOS_FAMILY = {
  ".SFUI": ".SFNS",
  ".SFUIRounded": ".SFNSRounded",
  ".SFUIMono": ".SFNSMono",
  ".SFUIItalic": ".SFNSItalic"
};
var index;
var psFamily = (ps) => ps.split("-")[0].replace(/\s+/g, "");
var nameFamily = (name) => name.split(";")[0].replace(/\s+/g, "");
function installed() {
  if (index) return index;
  index = [];
  for (const dir of FONT_DIRS) {
    let files = [];
    try {
      files = readdirSync(dir);
    } catch {
      continue;
    }
    for (const f of files) {
      if (!/\.(ttf|otf)$/i.test(f)) continue;
      const path = join(dir, f);
      try {
        const ps = psName(readFileSync(path));
        if (ps) index.push({ path, ps, family: psFamily(ps) });
      } catch {
      }
    }
  }
  return index;
}
function psName(b) {
  const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
  const n = dv.getUint16(4);
  for (let i = 0; i < n; i++) {
    const r = 12 + 16 * i;
    if (String.fromCharCode(...b.subarray(r, r + 4)) !== "name") continue;
    const t = dv.getUint32(r + 8);
    const count = dv.getUint16(t + 2);
    const str = t + dv.getUint16(t + 4);
    for (let k = 0; k < count; k++) {
      const e = t + 6 + 12 * k;
      if (dv.getUint16(e + 6) !== 6) continue;
      const [pid, len, off] = [dv.getUint16(e), dv.getUint16(e + 8), str + dv.getUint16(e + 10)];
      if (pid === 1) return String.fromCharCode(...b.subarray(off, off + len));
      let s = "";
      for (let j = 0; j < len; j += 2) s += String.fromCharCode(dv.getUint16(off + j));
      return s;
    }
  }
  return void 0;
}
var fonts = /* @__PURE__ */ new Map();
function resolveSystemFont(ps, coords, evidence) {
  const family = psFamily(ps);
  const want = IOS_TO_MACOS_FAMILY[family] ?? family;
  let list;
  try {
    list = installed();
  } catch {
    return { family, reason: "no font directories readable" };
  }
  const hit = list.find((f) => f.family === want) ?? list.find((f) => f.family === family);
  if (!hit) return { family, reason: `no installed font for ${family}` };
  const key = `${hit.path}|${JSON.stringify(coords)}`;
  let font = fonts.get(key);
  if (!font) {
    try {
      font = parseFont(new Uint8Array(readFileSync(hit.path)), hit.ps, coords);
    } catch {
      return { family, file: hit.path, reason: "installed font unreadable" };
    }
    fonts.set(key, font);
  }
  const byChar = /* @__PURE__ */ new Map();
  for (let g = font.numGlyphs - 1; g >= 0; g--) {
    const c = font.charFor(g);
    if (c) byChar.set(c, g);
  }
  let ok = 0;
  let bad = 0;
  for (const ev of evidence) {
    if (ev.family !== family) continue;
    for (const [orig, sub] of ev.pairs) {
      const c = ev.font.charFor(sub);
      if (!c) continue;
      if (byChar.get(c) === orig) ok++;
      else bad++;
    }
  }
  const dev = evidence.find((e) => e.family === family)?.version;
  if (bad) return { family, file: hit.path, reason: `installed ${font.version ?? hit.ps} glyph ids differ from the device's ${dev ?? family} (${bad} of ${ok + bad} mismatched)` };
  if (!ok) return { family, file: hit.path, reason: `no embedded ${family} subset in the archive to verify glyph ids against` };
  return { font, family, file: hit.path };
}

// extension/archive/render.ts
function pickState(a, opts = {}) {
  if (opts.stateIndex !== void 0) return a.states[opts.stateIndex];
  const tag = opts.viewTag ?? (a.viewTags.includes("listItem") ? "listItem" : a.viewTags[0]);
  const want = {
    colorScheme: (v) => v === (opts.colorScheme ?? "dark"),
    isLuminanceReduced: (v) => v === (opts.luminanceReduced ?? false),
    redactionReasons: (v) => v === (opts.redaction ?? 0),
    // full colour with the widget's own background
    widgetRenderScheme: (v) => v?.renderingMode?.mode === 0 && v?.backgroundViewPolicy === 0
  };
  let best;
  let bestScore = -1;
  for (const s of a.states) {
    if (s.viewTag !== tag) continue;
    let score = s.entry === 0 ? 100 : 0;
    for (const [k, v] of Object.entries(s.env)) if (want[k]?.(v)) score += k === "colorScheme" ? 4 : k === "redactionReasons" ? 2 : 1;
    if (score > bestScore) [best, bestScore] = [s, score];
  }
  return best;
}
function renderView(a, opts = {}) {
  const st = pickState(a, opts);
  if (!st) return null;
  const { size, nodes } = decodeState(a, st);
  const meta = st.metadata;
  const textColor = rgba(meta?.textColor) ?? [0, 0, 0, 1];
  const r = new Renderer(a, opts.idPrefix ?? `v${fnv(a.chunk(st.chunk)).toString(36)}`, opts.now ?? Date.now(), textColor);
  const body = r.nodes(nodes);
  const w = size.w || st.size.w;
  const h = size.h || st.size.h;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${num(w)} ${num(h)}" width="${num(w)}" height="${num(h)}">` + (r.defs.length ? `<defs>${r.defs.join("")}</defs>` : "") + body + "</svg>";
  return {
    svg,
    width: w,
    height: h,
    cornerRadius: st.cornerRadius,
    backgroundTint: rgba(meta?.backgroundTintColor),
    textColor: rgba(meta?.textColor),
    texts: r.texts.length ? r.texts : r.labels,
    warnings: [...r.warnings],
    state: st
  };
}
var num = (v) => String(+v.toFixed(3));
var rgba = (v) => Array.isArray(v) && v.length >= 3 && v.every((x) => typeof x === "number") ? [v[0], v[1], v[2], v[3] ?? 1] : void 0;
var IOS_ASCENT = 0.952;
var IOS_LINE_HEIGHT = 1.193;
var IOS_PROGRESS_THICKNESS = 4;
var IOS_PROGRESS_TRACK = [120 / 255, 120 / 255, 128 / 255, 0.25];
function formatTimer(t, now) {
  if (t.start === void 0 || t.end === void 0) return "";
  const total = Math.max(0, t.end - t.start);
  const ms = t.countdown ? Math.min(total, Math.max(0, t.end - now)) : Math.min(total, Math.max(0, now - t.start));
  const secs = t.countdown ? Math.ceil(ms / 1e3) : Math.floor(ms / 1e3);
  const [hh, mm, ss] = [Math.floor(secs / 3600), Math.floor(secs / 60) % 60, secs % 60];
  const p2 = (v) => String(v).padStart(2, "0");
  return hh ? `${hh}:${p2(mm)}:${p2(ss)}` : `${mm}:${p2(ss)}`;
}
function progressFraction(p, now) {
  if (p.start === void 0 || p.end === void 0 || p.end <= p.start) return p.fraction ?? 0;
  const f = Math.min(1, Math.max(0, (now - p.start) / (p.end - p.start)));
  return p.countdown ? 1 - f : f;
}
var fnv = (b) => b.reduce((h, c) => Math.imul(h ^ c, 16777619) >>> 0, 2166136261);
var esc = (s) => s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
var mat = (m) => `matrix(${m.map(num).join(" ")})`;
var isIdentity = (m) => m[0] === 1 && m[1] === 0 && m[2] === 0 && m[3] === 1 && m[4] === 0 && m[5] === 0;
var clamp01 = (v) => Math.max(0, Math.min(1, v));
var hexColor = (c) => "#" + c.slice(0, 3).map((v) => Math.round(clamp01(v) * 255).toString(16).padStart(2, "0")).join("");
function colorAttrs(c, prop = "fill") {
  const op = prop === "flood-color" ? "flood-opacity" : prop === "stop-color" ? "stop-opacity" : `${prop}-opacity`;
  return `${prop}="${hexColor(c)}"` + (c[3] < 1 ? ` ${op}="${num(clamp01(c[3]))}"` : "");
}
var BLEND = {
  1: "multiply",
  2: "screen",
  3: "overlay",
  4: "darken",
  5: "lighten",
  6: "color-dodge",
  7: "color-burn",
  8: "soft-light",
  9: "hard-light",
  10: "difference",
  11: "exclusion",
  12: "hue",
  13: "saturation",
  14: "color",
  15: "luminosity",
  26: "multiply",
  27: "plus-lighter"
};
var Renderer = class {
  constructor(a, prefix, now, textColor) {
    this.a = a;
    this.prefix = prefix;
    this.now = now;
    this.textColor = textColor;
  }
  a;
  prefix;
  now;
  textColor;
  defs = [];
  texts = [];
  labels = [];
  runs = [];
  labelStack = [];
  // content transitions: the innermost one applies; keys come from the nearest stable identity
  transitions = [];
  stableKeys = [];
  keyUses = /* @__PURE__ */ new Map();
  chars;
  // set while drawing text that the webapp animates per character
  charSource;
  charPos = 0;
  warnings = /* @__PURE__ */ new Set();
  ids = 0;
  glyphs = /* @__PURE__ */ new Map();
  id(p) {
    return `${this.prefix}${p}${this.ids++}`;
  }
  warn(s) {
    this.warnings.add(s);
  }
  nodes(ns) {
    return ns.map((n) => this.node(n)).join("");
  }
  node(n) {
    const { x, y } = n.frame;
    const at = (inner) => inner && (x || y) ? `<g transform="translate(${num(x)} ${num(y)})">${inner}</g>` : inner;
    let out = "";
    const stable = n.id !== void 0 ? this.a.stableId(n.id) : void 0;
    if (stable) this.stableKeys.push(stable);
    if (n.content) out += at(this.content(n.content, n.frame));
    if (n.effect) {
      const label = n.effect.kind === "accessibility" && n.effect.label && (n.effect.traits ?? 0) & 256 ? n.effect.label : void 0;
      const tr = n.effect.kind === "transition" ? n.effect.transition : void 0;
      if (label) this.labelStack.push(label);
      if (tr) this.transitions.push(tr);
      const inner = this.nodes(n.children ?? []);
      if (label) this.labelStack.pop();
      if (tr) this.transitions.pop();
      out += at(this.effect(n.effect, inner));
    }
    if (n.states?.length) out += at(this.nodes(n.states[0].children));
    if (stable) this.stableKeys.pop();
    return out;
  }
  effect(e, inner) {
    if (!inner) return "";
    switch (e.kind) {
      case "opacity":
        return e.value >= 1 ? inner : `<g opacity="${num(e.value)}">${inner}</g>`;
      case "transform":
        return isIdentity(e.m) ? inner : `<g transform="${mat(e.m)}">${inner}</g>`;
      case "clip": {
        if (!e.shape.parts.length) return inner;
        const id = this.id("c");
        const rule = e.shape.eo ? ' clip-rule="evenodd"' : "";
        this.defs.push(`<clipPath id="${id}">${e.shape.parts.map((p) => `<path d="${p.d}"${rule}/>`).join("")}</clipPath>`);
        return `<g clip-path="url(#${id})">${inner}</g>`;
      }
      case "mask": {
        const id = this.id("m");
        this.defs.push(`<mask id="${id}" maskUnits="userSpaceOnUse" x="-4000" y="-4000" width="8000" height="8000" style="mask-type:alpha">${this.nodes(e.children)}</mask>`);
        return `<g mask="url(#${id})">${inner}</g>`;
      }
      case "filter": {
        const fid = this.filter(e.filters);
        return fid ? `<g filter="url(#${fid})">${inner}</g>` : inner;
      }
      case "blend": {
        const mode = BLEND[e.mode];
        if (e.mode === 0) return inner;
        if (!mode) {
          this.warn(`blend mode ${e.mode} unsupported`);
          return e.mode === 23 ? "" : inner;
        }
        return `<g style="mix-blend-mode:${mode}">${inner}</g>`;
      }
      case "transition":
        return `<g data-la-transition="${e.transition.kind}">${inner}</g>`;
      case "accessibility":
        if (e.label && e.traits !== void 0 && e.traits & 256) this.labels.push(e.label);
        return inner;
      case "group":
      case "passthrough":
        return inner;
    }
  }
  filter(fs) {
    const prims = [];
    for (const f of fs) {
      switch (f.kind) {
        case "blur":
          prims.push(`<feGaussianBlur stdDeviation="${num(f.radius / 2)}"/>`);
          break;
        case "shadow":
          prims.push(`<feDropShadow dx="${num(f.dx)}" dy="${num(f.dy)}" stdDeviation="${num(f.radius / 2)}" ${colorAttrs(f.color, "flood-color")}/>`);
          break;
        case "matrix":
          prims.push(`<feColorMatrix type="matrix" values="${f.m.map(num).join(" ")}"/>`);
          break;
        case "saturation":
          prims.push(`<feColorMatrix type="saturate" values="${num(f.v)}"/>`);
          break;
        case "brightness":
          prims.push(`<feComponentTransfer>${["R", "G", "B"].map((c) => `<feFunc${c} type="linear" slope="1" intercept="${num(f.v)}"/>`).join("")}</feComponentTransfer>`);
          break;
        case "multiply":
          prims.push(`<feColorMatrix type="matrix" values="${num(f.color[0])} 0 0 0 0 0 ${num(f.color[1])} 0 0 0 0 0 ${num(f.color[2])} 0 0 0 0 0 ${num(f.color[3])} 0"/>`);
          break;
        case "luminanceToAlpha":
          prims.push('<feColorMatrix type="luminanceToAlpha"/>');
          break;
        default:
          this.warn(`filter ${f.field} unsupported`);
      }
    }
    if (!prims.length) return void 0;
    const id = this.id("f");
    this.defs.push(`<filter id="${id}" x="-50%" y="-50%" width="200%" height="200%" color-interpolation-filters="sRGB">${prims.join("")}</filter>`);
    return id;
  }
  content(c, frame2) {
    const { w, h } = frame2;
    switch (c.kind) {
      case "color":
        return `<rect width="${num(w)}" height="${num(h)}" ${colorAttrs(c.color)}/>`;
      case "image":
        return this.image(c.image, w, h);
      case "shadow": {
        if (!c.shape.parts.length) return "";
        const id = this.id("f");
        this.defs.push(`<filter id="${id}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="${num(c.radius / 2)}"/></filter>`);
        const shift = c.dx || c.dy ? ` transform="translate(${num(c.dx)} ${num(c.dy)})"` : "";
        return `<g filter="url(#${id})"${shift}>${this.parts(c.shape.parts, colorAttrs(c.color), c.shape.eo)}</g>`;
      }
      case "shape": {
        if (c.shape.badOp !== void 0) this.warn(`path op ${c.shape.badOp} unsupported`);
        const fill = this.paint(c.paint, frame2);
        return this.parts(c.shape.parts, fill, c.shape.eo);
      }
      case "drawing": {
        const rb = this.a.rb(c.chunk);
        if (!rb) {
          this.warn(`drawing chunk ${c.chunk} unreadable`);
          return "";
        }
        const first = this.runs.length;
        const tr = this.transitions.at(-1);
        const perChar = tr && (tr.kind === "numericText" || tr.kind === "text") && rb.entries.some((e) => e.item?.shape.kind === "glyphs");
        if (perChar) {
          this.chars = [];
          const label = [...this.labelStack.at(-1) ?? ""];
          const count = (l) => l.entries.reduce((n, e) => n + (e.item?.shape.kind === "glyphs" ? e.item.shape.glyphs.length : 0) + (e.group ? count(e.group) : 0), 0);
          this.charSource = label.length && label.length === count(rb) ? label : void 0;
          this.charPos = 0;
        }
        let inner = this.rb(rb);
        this.collectText(first);
        if (perChar && !this.chars.length) this.chars = void 0;
        if (perChar && this.chars) {
          const base = this.stableKeys.at(-1) ?? "root";
          const n = this.keyUses.get(base) ?? 0;
          this.keyUses.set(base, n + 1);
          const key = n ? `${base}.${n}` : base;
          const down = tr.countsDown ? ' data-la-counts-down="1"' : "";
          const value = tr.value !== void 0 ? ` data-la-value="${num(tr.value)}"` : "";
          inner = `<g data-la-numeric="${key}" data-la-text="${esc(this.chars.join(""))}"${down}${value}>${inner}</g>`;
        }
        this.chars = this.charSource = void 0;
        return c.offset.x || c.offset.y ? `<g transform="translate(${num(-c.offset.x)} ${num(-c.offset.y)})">${inner}</g>` : inner;
      }
      case "flattened": {
        const inner = this.nodes(c.children);
        return c.offset.x || c.offset.y ? `<g transform="translate(${num(-c.offset.x)} ${num(-c.offset.y)})">${inner}</g>` : inner;
      }
      case "text":
        return this.text(c, w, h);
      case "platformView": {
        const prog = c.chunk !== void 0 && c.chunk >= 0 && /ProgressView/.test(c.name) ? decodeProgress(this.a.chunk(c.chunk)) : void 0;
        if (prog) return this.progress(prog, w, h);
        this.warn(`platform view ${c.name} not archived`);
        return "";
      }
      case "backdrop":
        this.warn("backdrop blur approximated");
        return c.color ? `<rect width="${num(w)}" height="${num(h)}" ${colorAttrs(c.color)}/>` : "";
      case "unknown":
        this.warn(`content ${c.field} unsupported`);
        return "";
    }
  }
  text(c, w, h) {
    const col = c.color ?? this.textColor;
    const chars = [...c.text];
    if (chars.length && chars.every((ch) => ch.codePointAt(0) >= 1048576)) {
      const bh = h * 0.7;
      return `<rect y="${num((h - bh) / 2)}" width="${num(w)}" height="${num(bh)}" rx="${num(bh / 4)}" ${colorAttrs(col)}/>`;
    }
    const font = c.fontChunk !== void 0 && c.fontChunk >= 0 ? decodeFontDesc(this.a.chunk(c.fontChunk)) : void 0;
    if (!font?.size) this.warn("attributed text without a font descriptor");
    const size = font?.size || h / IOS_LINE_HEIGHT;
    const weight = font?.weight ?? 400;
    const family = (font?.rounded ? 'ui-rounded, "SF Pro Rounded", ' : "") + '-apple-system, "SF Pro", system-ui, sans-serif';
    const x = c.align === "middle" ? w / 2 : c.align === "end" ? w : 0;
    const y = (h - IOS_LINE_HEIGHT * size) / 2 + IOS_ASCENT * size;
    let value = c.text;
    let data = "";
    const t = c.timer;
    if (t && t.start !== void 0 && t.end !== void 0) {
      value = t.style === "timer" ? formatTimer(t, this.now) : c.text;
      data = ` data-la-timer-start="${Math.round(t.start)}" data-la-timer-end="${Math.round(t.end)}" data-la-timer-countdown="${t.countdown ? 1 : 0}" data-la-timer-style="${t.style}"`;
    }
    this.texts.push(value);
    const numeric = font?.monospacedDigits || c.tabular ? ' style="font-variant-numeric:tabular-nums"' : "";
    return `<text x="${num(x)}" y="${num(y)}" font-family='${family}' font-size="${num(size)}" font-weight="${weight}"${c.align !== "start" ? ` text-anchor="${c.align}"` : ""} ${colorAttrs(col)}${numeric}${data}>${esc(value)}</text>`;
  }
  // linear progress: ios draws a capsule bar of fixed thickness centred in the view's frame
  progress(p, w, h) {
    const y = (h - IOS_PROGRESS_THICKNESS) / 2;
    const r = IOS_PROGRESS_THICKNESS / 2;
    const tint = p.tint ?? this.textColor;
    let frac = p.fraction ?? 0;
    let data = "";
    if (p.start !== void 0 && p.end !== void 0) {
      frac = progressFraction(p, this.now);
      data = ` data-la-progress-start="${Math.round(p.start)}" data-la-progress-end="${Math.round(p.end)}" data-la-progress-countdown="${p.countdown ? 1 : 0}" data-la-progress-width="${num(w)}"`;
    }
    const bar = (fw, attrs, extra = "") => `<rect y="${num(y)}" width="${num(fw)}" height="${num(IOS_PROGRESS_THICKNESS)}" rx="${num(r)}" ${attrs}${extra}/>`;
    return bar(w, colorAttrs(IOS_PROGRESS_TRACK)) + bar(w * frac, colorAttrs(tint), data);
  }
  parts(parts, fill, eo) {
    return parts.map((p) => {
      if (p.stroke) {
        const s = p.stroke;
        const stroke = fill.replace(/^fill=/, "stroke=").replace(/fill-opacity=/, "stroke-opacity=");
        return `<path d="${p.d}" fill="none" ${stroke} stroke-width="${num(s.width)}"${s.cap !== "butt" ? ` stroke-linecap="${s.cap}"` : ""}${s.join !== "miter" ? ` stroke-linejoin="${s.join}"` : ""}${s.dash?.length ? ` stroke-dasharray="${s.dash.map(num).join(" ")}"${s.dashPhase ? ` stroke-dashoffset="${num(s.dashPhase)}"` : ""}` : ""}/>`;
      }
      return `<path d="${p.d}" ${fill}${eo ? ' fill-rule="evenodd"' : ""}/>`;
    }).join("");
  }
  paint(p, frame2) {
    switch (p.kind) {
      case "color":
        return colorAttrs(p.color);
      case "linear": {
        const [sx, sy] = p.units === "unit" ? [frame2.w, frame2.h] : [1, 1];
        return this.gradient("linear", p.stops, `x1="${num(p.from.x * sx)}" y1="${num(p.from.y * sy)}" x2="${num(p.to.x * sx)}" y2="${num(p.to.y * sy)}"`);
      }
      case "radial":
        return this.gradient("radial", p.stops, `cx="${num(p.center.x * frame2.w)}" cy="${num(p.center.y * frame2.h)}" r="${num(p.r1)}" fr="${num(p.r0)}"`);
      case "angular": {
        this.warn("angular gradient approximated");
        const avg = [0, 1, 2, 3].map((i) => p.stops.reduce((s, x) => s + x.color[i], 0) / (p.stops.length || 1));
        return colorAttrs(avg);
      }
      case "unknown":
        this.warn(`paint ${p.field} unsupported`);
        return 'fill="#808080"';
    }
  }
  gradient(kind, stops, attrs) {
    const id = this.id("g");
    const st = stops.map((s) => `<stop offset="${num(clamp01(s.at))}" ${colorAttrs(s.color, "stop-color")}/>`).join("");
    this.defs.push(`<${kind}Gradient id="${id}" gradientUnits="userSpaceOnUse" ${attrs}>${st}</${kind}Gradient>`);
    return `fill="url(#${id})"`;
  }
  image(img, w, h) {
    const src = img.source;
    switch (src.kind) {
      case "color":
        return `<rect width="${num(w)}" height="${num(h)}" ${colorAttrs(src.color)}/>`;
      case "vector": {
        const rb = this.a.rb(src.chunk);
        if (!rb || !src.size.w || !src.size.h) {
          this.warn(`vector image ${src.chunk} unreadable`);
          return "";
        }
        return `<g transform="matrix(${num(w / src.size.w)} 0 0 ${num(-h / src.size.h)} 0 ${num(h)})">${this.rb(rb, img.tint)}</g>`;
      }
      case "bitmap": {
        const b = this.a.chunk(src.chunk);
        const mime = b[0] === 137 && b[1] === 80 ? "image/png" : b[0] === 255 && b[1] === 216 ? "image/jpeg" : void 0;
        if (!mime) {
          this.warn(`bitmap ${src.chunk} has unknown encoding`);
          return "";
        }
        let filter = "";
        if (img.tint) {
          const id = this.id("t");
          this.defs.push(`<filter id="${id}" color-interpolation-filters="sRGB"><feFlood ${colorAttrs(img.tint, "flood-color")}/><feComposite in2="SourceGraphic" operator="in"/></filter>`);
          filter = ` filter="url(#${id})"`;
        }
        return `<image width="${num(w)}" height="${num(h)}" preserveAspectRatio="none"${filter} href="data:${mime};base64,${base64(b)}"/>`;
      }
      case "none":
        return "";
    }
  }
  // ------------------------------------------------------------ renderbox lists
  rb(list, tint) {
    return list.entries.map((e) => this.rbEntry(e, list, tint)).join("");
  }
  rbEntry(e, list, tint) {
    let out = "";
    if (e.item) out += this.rbItem(e.item, list, tint);
    if (e.group) out += this.rb({ entries: e.group.entries, resources: list.resources }, tint);
    if (!out) return "";
    for (const c of (e.clip !== void 0 ? list.resources.get(e.clip)?.clip : void 0) ?? []) {
      if (c.shape.kind !== "path") continue;
      const id = this.id("c");
      const t = isIdentity(c.m) ? "" : ` transform="${mat(c.m)}"`;
      const rule = c.shape.eo ? ' clip-rule="evenodd"' : "";
      this.defs.push(`<clipPath id="${id}">${c.shape.parts.map((p) => `<path d="${p.d}"${t}${rule}/>`).join("")}</clipPath>`);
      out = `<g clip-path="url(#${id})">${out}</g>`;
    }
    if (e.alpha !== void 0 && e.alpha < 1) out = `<g opacity="${num(e.alpha)}">${out}</g>`;
    if (e.blend) {
      const mode = BLEND[e.blend];
      if (mode) out = `<g style="mix-blend-mode:${mode}">${out}</g>`;
      else this.warn(`rb blend ${e.blend} unsupported`);
    }
    return out;
  }
  rbItem(it, list, tint) {
    const t = isIdentity(it.m) ? "" : ` transform="${mat(it.m)}"`;
    const s = it.shape;
    if (it.paint.kind === "image" && !tint && s.kind === "path") return `<g${t}>${this.rbImageFill(it.paint, s.parts, list)}</g>`;
    const fill = tint ? colorAttrs(tint) : this.rbPaint(it.paint);
    switch (s.kind) {
      case "path":
        if (s.badOp !== void 0) this.warn(`path op ${s.badOp} unsupported`);
        return `<g${t}>${this.parts(s.parts, fill, s.eo)}</g>`;
      case "fill":
        return `<rect x="-4000" y="-4000" width="8000" height="8000" ${fill}${t}/>`;
      case "glyphs": {
        const res = list.resources.get(s.font)?.font;
        if (!res) {
          this.warn(`glyph font ${s.font} missing`);
          return "";
        }
        let font;
        if (res.kind === "embedded") {
          font = this.a.font(res.chunk);
          if (!font) this.warn(`font chunk ${res.chunk} unreadable`);
        } else {
          const sys = this.a.systemFont(res.chunk);
          font = sys.font;
          if (!font) this.warn(`system font ${sys.family} not drawn: ${sys.reason}`);
        }
        if (!font) return "";
        const k = 1 / font.unitsPerEm;
        let text2 = "";
        const uses = s.glyphs.map((g) => {
          const ch = this.chars && this.charSource ? this.charSource[this.charPos++] : font.charFor(g.gid);
          text2 += ch ?? "\uFFFD";
          const wrap = (use) => {
            if (!this.chars || !ch || !use) return use;
            const i = this.chars.length;
            this.chars.push(ch);
            return `<g data-la-ch="${esc(ch)}" data-la-i="${i}">${use}</g>`;
          };
          const key = `${res.chunk}:${g.gid}`;
          let id = this.glyphs.get(key);
          if (id === void 0) {
            const d = font.glyphPath(g.gid);
            id = d ? this.id("gl") : "";
            if (d) this.defs.push(`<path id="${id}" d="${d}"/>`);
            this.glyphs.set(key, id);
          }
          if (!id && ch && this.chars) this.chars.push(ch);
          return wrap(id ? `<use href="#${id}" transform="translate(${num(g.x)} 0) scale(${k})"/>` : "");
        }).join("");
        this.runs.push({ text: text2, x: it.m[4], y: it.m[5] });
        const c = tint ?? (it.paint.kind === "color" ? it.paint.color : void 0);
        if (c && c[3] < 1) return `<g${t} ${colorAttrs([c[0], c[1], c[2], 1])} opacity="${num(clamp01(c[3]))}">${uses}</g>`;
        return `<g${t} ${fill}>${uses}</g>`;
      }
      case "unknown":
        this.warn(`rb shape ${s.field} unsupported`);
        return "";
    }
  }
  // runs of one drawing become one string: same baseline joins left to right, new baselines start a line
  collectText(first) {
    const runs = this.runs.splice(first);
    const lines = /* @__PURE__ */ new Map();
    for (const r of runs) {
      const k = Math.round(r.y);
      lines.set(k, [...lines.get(k) ?? [], r]);
    }
    const text2 = [...lines.entries()].sort((a, b) => a[0] - b[0]).map(([, rs]) => rs.sort((a, b) => a.x - b.x).map((r) => r.text).join("")).join("\n").trim();
    const label = this.labelStack.at(-1);
    if (text2 && !text2.includes("\uFFFD")) this.texts.push(text2);
    else if (runs.length && label) this.texts.push(label);
  }
  // image paint: clip to the shape and draw the bitmap over the unit square mapped by the paint transform
  rbImageFill(p, parts, list) {
    const chunk = list.resources.get(p.resource)?.image;
    const b = chunk !== void 0 ? this.a.chunk(chunk) : void 0;
    const mime = b && b[0] === 137 && b[1] === 80 ? "image/png" : b && b[0] === 255 && b[1] === 216 ? "image/jpeg" : void 0;
    if (!b || !mime) {
      this.warn("rb image paint without a decodable image");
      return "";
    }
    const id = this.id("c");
    this.defs.push(`<clipPath id="${id}">${parts.map((q) => `<path d="${q.d}"/>`).join("")}</clipPath>`);
    const op = p.color && p.color[3] < 1 ? ` opacity="${num(clamp01(p.color[3]))}"` : "";
    const m = mat(p.m);
    return `<g clip-path="url(#${id})"${op}><image width="1" height="1" preserveAspectRatio="none" transform="${m}" href="data:${mime};base64,${base64(b)}"/></g>`;
  }
  rbPaint(p) {
    switch (p.kind) {
      case "image":
        this.warn("rb image paint on a non-path shape unsupported");
        return 'fill="none"';
      case "color":
        return colorAttrs(p.color);
      case "linear":
        return this.gradient("linear", p.stops, `x1="${num(p.from.x)}" y1="${num(p.from.y)}" x2="${num(p.to.x)}" y2="${num(p.to.y)}"`);
      case "unknown":
        this.warn(`rb paint ${p.field} unsupported`);
        return 'fill="#808080"';
    }
  }
};

// extension/archive/decode.ts
var MAGIC = 3512081009;
function readArchive(bytes) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (bytes.length < 8 || dv.getUint32(bytes.length - 4, true) !== MAGIC) throw new Error("not a swiftui archive");
  const count = dv.getUint32(bytes.length - 8, true);
  const idx = bytes.length - 8 - 16 * count;
  if (idx < 0) throw new Error("bad chunk index");
  const chunks = [];
  for (let i = 0; i < count; i++) {
    const off = Number(dv.getBigUint64(idx + 16 * i, true));
    const len = Number(dv.getBigUint64(idx + 16 * i + 8, true));
    chunks.push(bytes.subarray(off, off + len));
  }
  const text2 = (b) => new TextDecoder().decode(b);
  const manifest = JSON.parse(text2(chunks[count - 1]));
  const raw = chunks[manifest.dataAttachment];
  if (!raw) throw new Error("missing data attachment");
  const data = isBplist(raw) ? parseBplist(raw) : JSON.parse(text2(raw));
  const stateChunks = manifest.stateAttachments ?? [];
  const states = [];
  let kind;
  let viewTags;
  if (Array.isArray(data.viewTags)) {
    kind = "activity";
    viewTags = data.viewTags;
    const meta = data.viewEntryMetadata ?? [];
    const seen = /* @__PURE__ */ new Map();
    meta.forEach((m, i) => {
      const tag = m.viewTag;
      const family = tag.startsWith("dynamicIsland") ? "dynamicIsland" : tag;
      const k = seen.get(tag) ?? 0;
      seen.set(tag, k + 1);
      const [w = 0, h = 0] = m.metrics?.bounds?.[1] ?? [];
      states.push({
        index: i,
        chunk: stateChunks[i],
        viewTag: tag,
        size: { w, h },
        cornerRadius: m.metrics?.cornerRadius,
        ...envCombo(data[family]?.environment ?? {}, k),
        metadata: m.listItemViewMetadata
      });
    });
  } else {
    kind = "widget";
    viewTags = ["widget"];
    stateChunks.forEach((c, i) => {
      const s = new Msg(chunks[c] ?? new Uint8Array()).msg(1);
      states.push({
        index: i,
        chunk: c,
        viewTag: "widget",
        size: { w: s?.float(1) ?? 0, h: s?.float(2) ?? 0 },
        ...envCombo(data.environment ?? {}, i),
        metadata: data.viewMetadata?.[i]
      });
    });
  }
  const fonts2 = /* @__PURE__ */ new Map();
  const sysFonts = /* @__PURE__ */ new Map();
  let stableIds;
  let evidence;
  const embedded = () => {
    if (evidence) return evidence;
    evidence = [];
    chunks.forEach((c, i) => {
      if (c[0] !== 10 || !c.length) return;
      let m;
      try {
        m = new Msg(c);
      } catch {
        return;
      }
      const name = m.str(2);
      const pairs = m.msgs(3).map((p) => [p.int(1), p.int(2)]);
      if (!name || !pairs.length || !m.bytesOf(1)) return;
      const font = archive.font(i);
      if (font) evidence.push({ family: nameFamily(name), version: name, font, pairs });
    });
    return evidence;
  };
  const rbs = /* @__PURE__ */ new Map();
  const archive = {
    bytes,
    chunks,
    manifest,
    data,
    kind,
    viewTags,
    states,
    chunk: (i) => chunks[i] ?? new Uint8Array(0),
    font(c) {
      if (!fonts2.has(c)) {
        let f;
        try {
          const m = new Msg(chunks[c] ?? new Uint8Array());
          const sf = m.bytesOf(1);
          if (sf) f = parseFont(sf, m.str(2) ?? "");
        } catch {
        }
        fonts2.set(c, f);
      }
      return fonts2.get(c);
    },
    systemFont(c) {
      let r = sysFonts.get(c);
      if (!r) {
        const m = Msg.from({ no: 0, wt: 2, v: 0, raw: chunks[c] ?? new Uint8Array() });
        const ps = m.str(3) ?? m.str(5) ?? "";
        const coords = {};
        const vars = plistAt(m.bytesOf(10));
        try {
          for (const [k, v] of Object.entries(typeof vars === "string" ? JSON.parse(vars) : vars ?? {}))
            coords[String.fromCharCode(...[24, 16, 8, 0].map((sh) => Number(k) >>> sh & 255))] = Number(v);
        } catch {
        }
        r = ps ? resolveSystemFont(ps, coords, embedded()) : { family: "", reason: "font descriptor without a name" };
        sysFonts.set(c, r);
      }
      return r;
    },
    stableId(id) {
      if (!stableIds) {
        stableIds = /* @__PURE__ */ new Map();
        try {
          for (const e of new Msg(chunks[manifest.stableIDsAttachment] ?? new Uint8Array()).msgs(1)) {
            const h = e.msg(2)?.msg(1);
            if (h) stableIds.set(e.int(1), hex(h.bytesOf(1) ?? h.bytes));
          }
        } catch {
        }
      }
      return stableIds.get(id);
    },
    rb(c) {
      if (!rbs.has(c)) {
        let r;
        try {
          if (chunks[c]) r = decodeRBChunk(new Msg(chunks[c]));
        } catch {
        }
        rbs.set(c, r);
      }
      return rbs.get(c);
    }
  };
  return archive;
}
function envKeys(env) {
  return Object.keys(env).filter((k) => Array.isArray(env[k]) && env[k].length > 1).sort();
}
function envCombo(env, index2) {
  const out = {};
  const keys = envKeys(env);
  let rest = index2;
  for (let i = keys.length - 1; i >= 0; i--) {
    const vals = env[keys[i]];
    out[keys[i]] = vals[rest % vals.length];
    rest = Math.floor(rest / vals.length);
  }
  return { env: out, entry: rest };
}
var CAPS = ["butt", "round", "square"];
var JOINS = ["miter", "round", "bevel"];
var f32s = (b) => {
  if (!b || b.length < 4) return void 0;
  const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
  return Array.from({ length: Math.floor(b.length / 4) }, (_, i) => dv.getFloat32(4 * i, true));
};
function decodeState(a, s) {
  const m = new Msg(a.chunk(s.chunk));
  const sz = m.msg(1);
  return { size: { w: sz?.float(1) ?? s.size.w, h: sz?.float(2) ?? s.size.h }, nodes: decodeList(m.msg(2)) };
}
var rect = (m) => ({ x: m?.float(1) ?? 0, y: m?.float(2) ?? 0, w: m?.float(3) ?? 0, h: m?.float(4) ?? 0 });
var pt = (m) => ({ x: m?.float(1) ?? 0, y: m?.float(2) ?? 0 });
var affine = (m) => [m?.float(1, 1) ?? 1, m?.float(2) ?? 0, m?.float(3) ?? 0, m?.float(4, 1) ?? 1, m?.float(5) ?? 0, m?.float(6) ?? 0];
var lin2srgb = (v) => {
  const a = Math.abs(v);
  const s = a <= 31308e-7 ? a * 12.92 : 1.055 * a ** (1 / 2.4) - 0.055;
  return Math.sign(v) * s;
};
function resolvedColor(m) {
  return [lin2srgb(m?.float(1) ?? 0), lin2srgb(m?.float(2) ?? 0), lin2srgb(m?.float(3) ?? 0), m?.float(4, 1) ?? 1];
}
function decodeList(m) {
  return m ? m.msgs(1).map(decodeNode) : [];
}
function decodeNode(m) {
  const n = { frame: rect(m.msg(3)) };
  if (m.has(4)) n.id = m.int(4);
  const c = m.msg(1);
  if (c) n.content = decodeContent(c.msg(1));
  const e = m.msg(2);
  if (e) {
    n.effect = decodeEffect(e.msg(1));
    n.children = decodeList(e.msg(2));
  }
  const s = m.msg(5);
  if (s) n.states = s.msgs(1).map((st) => ({ hash: hex(st.msg(1)?.bytesOf(1) ?? new Uint8Array()), children: decodeList(st.msg(2)) }));
  return n;
}
function decodeContent(v) {
  const f = v?.fields[0];
  if (!v || !f) return { kind: "unknown", field: 0 };
  const m = Msg.from(f);
  switch (f.no) {
    case 1:
      return { kind: "color", color: resolvedColor(m) };
    case 2:
      return { kind: "image", image: decodeImage(m) };
    case 3:
      return { kind: "shape", shape: decodePath(m.msg(1)), paint: decodePaint(m.msg(2)) };
    case 4:
      return decodeAttributedText(m);
    case 5: {
      const st = m.msg(2);
      const off = st?.msg(3);
      return { kind: "shadow", shape: decodePath(m.msg(1)), color: resolvedColor(st?.msg(1)), radius: st?.float(2) ?? 0, dx: off?.float(1) ?? 0, dy: off?.float(2) ?? 0 };
    }
    case 6:
      return { kind: "flattened", children: decodeList(m.msg(1)), offset: pt(m.msg(2)) };
    case 7:
      return { kind: "platformView", name: m.str(1) ?? "", chunk: m.msg(2)?.int(1, -1) };
    case 11: {
      const col = m.msg(2);
      return { kind: "backdrop", color: col ? resolvedColor(col) : void 0 };
    }
    case 13:
      return { kind: "drawing", chunk: m.msg(1)?.int(1) ?? -1, offset: pt(m.msg(2)) };
    default:
      return { kind: "unknown", field: f.no };
  }
}
function decodeAttributedText(m) {
  const body = m.msg(1);
  const runs = body?.msgs(1) ?? [];
  const attrs = runs[0]?.msg(2);
  const sz = m.msg(2);
  const col = attrs?.msg(4);
  const format = plistAt(attrs?.bytesOf(35));
  const fmt = format?.value?.format;
  const align = ["start", "middle", "end"][fmt?.textAlignment?.value ?? 0] ?? "start";
  return {
    kind: "text",
    text: runs.map((r) => new TextDecoder().decode(r.bytesOf(1) ?? new Uint8Array())).join(""),
    color: col ? resolvedColor(col) : void 0,
    size: sz ? { w: sz.float(1), h: sz.float(2) } : void 0,
    fontChunk: attrs?.msg(3)?.int(1, -1),
    align,
    tabular: !!fmt?.monospacedDigits,
    timer: decodeTimer(plistAt(body?.bytesOf(4)), format)
  };
}
var appleMs = (d) => d instanceof Date ? d.getTime() : typeof d === "number" ? (d + 978307200) * 1e3 : void 0;
function plistAt(b) {
  if (!b || !isBplist(b)) return void 0;
  try {
    const p = parseBplist(b);
    return Array.isArray(p) ? p[0] : p;
  } catch {
    return void 0;
  }
}
function decodeTimer(src, format) {
  const type = format?.type ?? "";
  const fmt = format?.value?.format;
  const style = type.match(/SystemFormatStyleO\d+(?:\d+)?([A-Z][A-Za-z]*?)V/)?.[1]?.toLowerCase() ?? (src?.timerInterval ? "timer" : void 0);
  if (!style && !src) return void 0;
  const ti = src?.timerInterval;
  let start2 = appleMs(ti?.start ?? fmt?.startDate ?? src?.date);
  let end;
  if (ti && typeof ti.duration === "number" && start2 !== void 0) end = start2 + ti.duration * 1e3;
  else if (Array.isArray(fmt?.interval) && start2 !== void 0) {
    const [hi, lo] = fmt.interval;
    end = start2 + (hi * 2 ** 64 + lo) / 1e15;
  }
  const countdown = !!(src?.countdowns ?? fmt?.countingMode?.timer?.countsdown);
  if (start2 === void 0 && end === void 0) return void 0;
  return { style: style ?? "timer", start: start2, end, countdown };
}
function decodeFontDesc(b) {
  let m;
  try {
    m = new Msg(b);
  } catch {
    return void 0;
  }
  const name = m.str(5) ?? m.str(3) ?? "";
  const size = m.float(7);
  if (!name && !size) return void 0;
  const json2 = (no) => {
    const p = plistAt(m.bytesOf(no));
    try {
      return typeof p === "string" ? JSON.parse(p) : p;
    } catch {
      return void 0;
    }
  };
  const vars = json2(10);
  const feats = json2(9) ?? [];
  let weight = Number(vars?.[String(2003265652)]);
  if (!weight) {
    const n = name.toLowerCase();
    const table = [["ultralight", 100], ["thin", 200], ["light", 300], ["medium", 500], ["semibold", 600], ["demi", 600], ["heavy", 800], ["black", 900], ["bold", 700]];
    weight = table.find(([k]) => n.includes(k))?.[1] ?? 400;
  }
  return {
    name,
    size,
    weight,
    rounded: /rounded/i.test(name),
    // feature type 6 selector 0 is monospaced numbers
    monospacedDigits: feats.some((f) => f?.CTFeatureTypeIdentifier === 6 && f?.CTFeatureSelectorIdentifier === 0)
  };
}
function decodeProgress(b) {
  const p = plistAt(b);
  const v = p?.view;
  if (!v) return void 0;
  const iv = Array.isArray(v.interval) ? v.interval : void 0;
  const t = v.resolvedTint;
  let fraction;
  if (typeof v.fractionCompleted === "number") fraction = v.fractionCompleted;
  else if (typeof v.value === "number") fraction = v.value / (typeof v.total === "number" && v.total ? v.total : 1);
  return {
    start: appleMs(iv?.[0]),
    end: appleMs(iv?.[1]),
    countdown: !!v.countdown,
    fraction,
    tint: Array.isArray(t) && t.length >= 3 ? [t[0], t[1], t[2], t[3] ?? 1] : void 0
  };
}
function decodeImage(m) {
  const px = m.msg(6);
  const img = { source: { kind: "none" }, scale: m.float(5, 1), pixelSize: { w: px?.float(1) ?? 0, h: px?.float(2) ?? 0 } };
  if (m.has(1)) img.source = { kind: "color", color: resolvedColor(m.msg(1)) };
  else if (m.has(2)) img.source = { kind: "bitmap", chunk: m.msg(2).int(1, -1) };
  else if (m.has(3)) {
    const v = m.msg(3);
    const sz = v.msg(2);
    img.source = { kind: "vector", chunk: v.msg(1)?.int(1, -1) ?? -1, size: { w: sz?.float(1) ?? 0, h: sz?.float(2) ?? 0 } };
  }
  if (m.has(8)) img.tint = resolvedColor(m.msg(8));
  return img;
}
function decodePath(m) {
  if (!m) return { parts: [] };
  if (m.has(1)) {
    const r = rect(m.msg(1));
    return { parts: [{ d: rectD(r) }], bounds: r };
  }
  if (m.has(2)) {
    const r = rect(m.msg(2));
    return { parts: [{ d: ellipseD(r) }], bounds: r };
  }
  if (m.has(3)) {
    const rr = m.msg(3);
    const r = rect(rr.msg(1));
    const cs = rr.msg(2);
    return { parts: [{ d: rrectD(r, cs?.float(1) ?? 0, cs?.float(2) ?? 0, rr.int(3) === 1) }], bounds: r };
  }
  if (m.has(4)) {
    const { parts, badOp } = rbPath(m.msg(4));
    return { parts, badOp };
  }
  return { parts: [] };
}
function decodeStops(g, packed) {
  if (packed?.colors) {
    const c = packed.colors;
    const dv = new DataView(c.buffer, c.byteOffset, c.byteLength);
    const locs = packed.locs ? new DataView(packed.locs.buffer, packed.locs.byteOffset, packed.locs.byteLength) : void 0;
    const n = c.length / 8;
    return Array.from({ length: n }, (_, i) => ({
      color: [0, 1, 2, 3].map((k) => f16(dv.getUint16(8 * i + 2 * k, true))),
      at: locs && locs.byteLength >= 4 * (i + 1) ? locs.getFloat32(4 * i, true) : n > 1 ? i / (n - 1) : 0
    }));
  }
  return (g?.msgs(1) ?? []).map((s) => ({ color: resolvedColor(s.msg(1)), at: s.float(2) }));
}
function decodePaint(m) {
  const f = m?.fields[0];
  if (!m || !f) return { kind: "color", color: [0, 0, 0, 1] };
  const p = Msg.from(f);
  switch (f.no) {
    case 1:
      return { kind: "color", color: resolvedColor(p) };
    case 2: {
      const from = p.msg(2);
      const to = p.msg(3);
      return { kind: "linear", stops: decodeStops(p.msg(1)), from: pt(from), to: pt(to), units: "unit" };
    }
    case 10:
      return { kind: "linear", stops: decodeStops(p.msg(1)), from: pt(p.msg(2)), to: pt(p.msg(3)), units: "abs" };
    case 3:
      return { kind: "radial", stops: decodeStops(p.msg(1)), center: pt(p.msg(2)), r0: p.float(3), r1: p.float(4) };
    case 4:
      return { kind: "angular", stops: decodeStops(p.msg(1)), center: pt(p.msg(2)), start: p.float(3), end: p.float(4, Math.PI * 2) };
    default:
      return { kind: "unknown", field: f.no };
  }
}
function decodeEffect(m) {
  const f = m?.fields[0];
  if (!m || !f) return { kind: "passthrough", field: 0 };
  const e = Msg.from(f);
  switch (f.no) {
    case 3:
      return { kind: "opacity", value: m.float(3, 1) };
    case 4:
      return { kind: "blend", mode: e?.int(1) ?? 0 };
    case 5:
      return { kind: "clip", shape: { ...decodePath(e?.msg(1)), eo: e?.msg(2)?.bool(1) ?? false } };
    case 6:
      return { kind: "mask", children: decodeList(e?.msg(1)) };
    case 7:
      return { kind: "transform", m: affine(e) };
    case 9:
      return { kind: "filter", filters: e ? [decodeFilter(e)] : [] };
    case 12:
      return { kind: "group", name: e?.str(1) };
    case 14:
      return accessibility(e);
    case 16:
      return { kind: "transition", transition: decodeTransition(e) };
    case 21: {
      const a = e?.float(1) ?? 0;
      const c = pt(e?.msg(2));
      const [cos, sin] = [Math.cos(a), Math.sin(a)];
      return { kind: "transform", m: [cos, sin, -sin, cos, c.x - cos * c.x + sin * c.y, c.y - sin * c.x - cos * c.y] };
    }
    case 22: {
      const a = e?.float(1) ?? 0;
      const [ax, ay] = [e?.float(2) ?? 0, e?.float(3) ?? 0];
      const [cx, cy] = [e?.float(5) ?? 0, e?.float(6) ?? 0];
      const len = Math.hypot(ax, ay, e?.float(4) ?? 0) || 1;
      const sx = 1 - (1 - Math.cos(a)) * (ay / len) ** 2;
      const sy = 1 - (1 - Math.cos(a)) * (ax / len) ** 2;
      return { kind: "transform", m: [sx, 0, 0, sy, cx - sx * cx, cy - sy * cy] };
    }
    default:
      return { kind: "passthrough", field: f.no };
  }
}
function decodeTransition(e) {
  const t = e.msg(1);
  const styleOf = (m) => m?.has(1) ? "sessionWidget" : m?.has(2) ? "animatedWidget" : void 0;
  const named = t?.msg(1);
  const style = styleOf(named?.msg(8) ?? e.msg(2));
  if (!named) return { kind: t?.has(2) ? "custom" : "unknown", style };
  const f = named.fields.find((x) => x.no !== 8);
  const kinds = ["unknown", "default", "identity", "opacity", "interpolate", "text", "numericText"];
  const out = { kind: f && kinds[f.no] || (f ? "unknown" : "default"), style };
  if (f?.no === 6) {
    const n = Msg.from(f);
    if (n.has(1)) out.countsDown = n.int(1) === 1;
    if (n.has(2)) out.value = n.float(2);
  }
  return out;
}
function decodeFilter(m) {
  const f = m.fields[0];
  if (!f) return { kind: "unknown", field: 0 };
  const p = Msg.from(f);
  switch (f.no) {
    case 1:
      return { kind: "blur", radius: p?.float(1) ?? 0 };
    case 2: {
      const off = p?.msg(3);
      return { kind: "shadow", color: resolvedColor(p?.msg(1)), radius: p?.float(2) ?? 0, dx: off?.float(1) ?? 0, dy: off?.float(2) ?? 0 };
    }
    case 4: {
      const id = [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0];
      return { kind: "matrix", m: id.map((v, i) => p?.float(i + 1, v) ?? v) };
    }
    case 14: {
      const id = [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0];
      return { kind: "matrix", m: [...id.map((v, i) => p?.float(i + 1, v) ?? v), 0, 0, 0, 1, 0] };
    }
    case 5:
      return { kind: "multiply", color: resolvedColor(p) };
    case 7:
      return { kind: "saturation", v: m.float(7, 1) };
    case 8:
      return { kind: "brightness", v: m.float(8, 0) };
    case 10:
      return { kind: "luminanceToAlpha" };
    default:
      return { kind: "unknown", field: f.no };
  }
}
function accessibility(e) {
  const props = e?.msg(1)?.msg(1)?.msg(3)?.msg(1);
  const t = props?.msg(2)?.msg(3)?.msg(2)?.bytesOf(1);
  const label = t && !(t[0] >= 240) ? new TextDecoder().decode(t) : void 0;
  return { kind: "accessibility", label, traits: props?.msg(6)?.int(1) };
}
var n2 = (v) => +v.toFixed(3);
var plain = (x, y) => `${n2(x)} ${n2(y)}`;
var mapper = (t) => t ? (x, y) => plain(t[0] * x + t[2] * y + t[4], t[1] * x + t[3] * y + t[5]) : plain;
var rectD = (r, P = plain) => `M${P(r.x, r.y)}L${P(r.x + r.w, r.y)}L${P(r.x + r.w, r.y + r.h)}L${P(r.x, r.y + r.h)}Z`;
function ellipseD(r, P = plain) {
  const [rx, ry, cx, cy] = [r.w / 2, r.h / 2, r.x + r.w / 2, r.y + r.h / 2];
  let d = `M${P(cx + rx, cy)}`;
  for (let q = 0; q < 4; q++) d += arcCubic(cx, cy, rx, ry, q * Math.PI / 2, (q + 1) * Math.PI / 2, P);
  return d + "Z";
}
function rrectD(r, rx, ry, continuous = false, P = plain) {
  return unevenRRectD(r, [rx, rx, rx, rx], [ry, ry, ry, ry], continuous, P);
}
function unevenRRectD(r, rxs, rys, continuous, P = plain) {
  const k = continuous ? 0.62 : 0.5523;
  const cl = (v, max) => Math.max(0, Math.min(v, max));
  const c = (i) => [cl(rxs[i] ?? 0, r.w / 2), cl(rys[i] ?? 0, r.h / 2)];
  const [tl, bl, br, tr] = [c(0), c(1), c(2), c(3)];
  const { x, y, w, h } = r;
  const corner = (x0, y0, cx, cy, x1, y1) => `C${P(x0 + (cx - x0) * k, y0 + (cy - y0) * k)} ${P(x1 + (cx - x1) * k, y1 + (cy - y1) * k)} ${P(x1, y1)}`;
  let d = `M${P(x + tl[0], y)}L${P(x + w - tr[0], y)}`;
  if (tr[0] || tr[1]) d += corner(x + w - tr[0], y, x + w, y, x + w, y + tr[1]);
  d += `L${P(x + w, y + h - br[1])}`;
  if (br[0] || br[1]) d += corner(x + w, y + h - br[1], x + w, y + h, x + w - br[0], y + h);
  d += `L${P(x + bl[0], y + h)}`;
  if (bl[0] || bl[1]) d += corner(x + bl[0], y + h, x, y + h, x, y + h - bl[1]);
  d += `L${P(x, y + tl[1])}`;
  if (tl[0] || tl[1]) d += corner(x, y + tl[1], x, y, x + tl[0], y);
  return d + "Z";
}
function arcCubic(cx, cy, rx, ry, a0, a1, P) {
  const k = 4 / 3 * Math.tan((a1 - a0) / 4);
  const [c0, s0, c1, s1] = [Math.cos(a0), Math.sin(a0), Math.cos(a1), Math.sin(a1)];
  return `C${P(cx + rx * (c0 - k * s0), cy + ry * (s0 + k * c0))} ${P(cx + rx * (c1 + k * s1), cy + ry * (s1 - k * c1))} ${P(cx + rx * c1, cy + ry * s1)}`;
}
function rbPath(m, base) {
  const ops = m.bytesOf(3) ?? new Uint8Array();
  const pb = m.bytesOf(2) ?? new Uint8Array();
  const f = new DataView(pb.buffer, pb.byteOffset, pb.byteLength);
  const extra = m.msg(4);
  const xforms = extra?.msgs(1) ?? [];
  const styles = extra?.msgs(2) ?? [];
  let fi = 0;
  const take = (n) => {
    const out = [];
    for (let i = 0; i < n; i++, fi++) out.push(fi * 4 + 4 <= pb.length ? f.getFloat32(fi * 4, true) : 0);
    return out;
  };
  const stack = [{ xf: base }];
  const parts = [];
  let d = "";
  const P = (x, y) => {
    let t;
    for (const fr of stack) if (fr.xf) t = t ? mul(t, fr.xf) : fr.xf;
    return mapper(t)(x, y);
  };
  const flush = () => {
    if (!d) return;
    const stroke = stack.findLast((s) => s.stroke)?.stroke;
    parts.push(stroke ? { d, stroke } : { d });
    d = "";
  };
  let ti = 0;
  let si = 0;
  for (const raw of ops) {
    const op = raw & 127;
    const flag = raw & 128;
    switch (op) {
      case 0:
      case 1: {
        const [x, y] = take(2);
        d += (op ? "L" : "M") + P(x, y);
        break;
      }
      case 2: {
        const [a, b, x, y] = take(4);
        d += `Q${P(a, b)} ${P(x, y)}`;
        break;
      }
      case 3: {
        const [a, b, c, e, x, y] = take(6);
        d += `C${P(a, b)} ${P(c, e)} ${P(x, y)}`;
        break;
      }
      case 4:
        d += "Z";
        break;
      case 5:
      case 7:
      case 8:
      case 9:
      case 10:
      case 11: {
        const v = take(op >= 10 ? 8 : op >= 8 ? 6 : 4);
        const r = { x: v[0], y: v[1], w: v[2], h: v[3] };
        if (op === 5) d += rectD(r, P);
        else if (op === 7) d += ellipseD(r, P);
        else if (op <= 9) d += rrectD(r, v[4], v[5], op === 9, P);
        else d += unevenRRectD(r, v.slice(4), v.slice(4), op === 11, P);
        break;
      }
      case 13:
      case 14: {
        const [cx, cy, rad, a0, a1] = take(5);
        let delta = a1 - a0;
        if (op === 14) while (delta < 0) delta += 2 * Math.PI;
        else while (delta > 0) delta -= 2 * Math.PI;
        d += (d ? "L" : "M") + P(cx + rad * Math.cos(a0), cy + rad * Math.sin(a0));
        const steps = Math.max(1, Math.ceil(Math.abs(delta) / (Math.PI / 2)));
        for (let i = 0; i < steps; i++) d += arcCubic(cx, cy, rad, rad, a0 + delta * i / steps, a0 + delta * (i + 1) / steps, P);
        break;
      }
      case 17:
        flush();
        stack.push({ xf: flag ? affine(xforms[ti++]) : void 0 });
        break;
      case 19: {
        flush();
        const [w, miter, phase] = take(3);
        const st = flag ? styles[si++] : void 0;
        const cap = CAPS[st?.int(1) ?? 0] ?? "butt";
        const join4 = JOINS[st?.int(2) ?? 0] ?? "miter";
        const dash = f32s(st?.bytesOf(3));
        stack.push({ stroke: { width: w, miter, cap, join: join4, ...dash ? { dash, dashPhase: phase } : {} } });
        break;
      }
      case 20:
        flush();
        stack.push({});
        break;
      case 21:
        flush();
        break;
      case 16:
        flush();
        if (stack.length > 1) stack.pop();
        break;
      default:
        flush();
        return { parts, badOp: raw };
    }
  }
  flush();
  return { parts };
}
var mul = (a, b) => [
  a[0] * b[0] + a[2] * b[1],
  a[1] * b[0] + a[3] * b[1],
  a[0] * b[2] + a[2] * b[3],
  a[1] * b[2] + a[3] * b[3],
  a[0] * b[4] + a[2] * b[5] + a[4],
  a[1] * b[4] + a[3] * b[5] + a[5]
];
function decodeRBChunk(m) {
  const resources = /* @__PURE__ */ new Map();
  for (const r of m.msgs(15)) {
    const id = r.int(1);
    const res = { id };
    const fr = r.msg(3)?.msg(1);
    if (fr?.has(3)) res.font = { kind: "embedded", chunk: fr.msg(3).int(1, -1) };
    else if (fr?.has(4)) res.font = { kind: "system", chunk: fr.msg(4).int(1, -1) };
    if (r.has(2)) res.image = r.msg(2)?.msg(1)?.msg(1)?.int(1, -1);
    if (r.has(4)) res.clip = r.msg(4).msgs(1).map((c) => ({ shape: decodeRBShape(c.msg(1)?.msg(1)), m: affine(c.msg(1)?.msg(2)) }));
    resources.set(id, res);
  }
  return decodeRBList(m.msg(1) ?? Msg.from(void 0), resources);
}
function decodeRBList(m, resources) {
  return { entries: m.msgs(1).map((e) => decodeRBEntry(e, resources)), resources };
}
function decodeRBEntry(m, resources) {
  const e = {};
  const it = m.msg(1);
  if (it) e.item = { shape: decodeRBShape(it.msg(1)), paint: decodeRBPaint(it.msg(2)), m: affine(it.msg(3)) };
  if (m.has(2)) e.group = decodeRBList(m.msg(2).msg(1) ?? Msg.from(void 0), resources);
  if (m.has(4)) e.alpha = m.float(4, 1);
  if (m.has(5)) e.blend = m.int(5);
  if (m.has(6)) e.clip = m.msg(6).int(1);
  return e;
}
function decodeRBShape(m) {
  const f = m?.fields[0];
  if (!m || !f) return { kind: "unknown", field: 0 };
  const s = Msg.from(f);
  switch (f.no) {
    case 1: {
      if (!s.has(2)) return { kind: "fill" };
      const r = rect(s.msg(2));
      const rad = s.float(3);
      const d = rad ? rrectD(r, rad, rad, s.int(1) === 4) : rectD(r);
      const w = s.float(6);
      return { kind: "path", parts: [w ? { d, stroke: { width: w, cap: "butt", join: "miter", miter: 10 } } : { d }] };
    }
    case 2: {
      const { parts, badOp } = rbPath(s.msg(1) ?? Msg.from(void 0), s.has(2) ? affine(s.msg(2)) : void 0);
      return { kind: "path", parts, eo: s.int(3) === 1, badOp };
    }
    case 3: {
      const stroke = { width: s.float(3, 1), cap: CAPS[s.int(4)] ?? "butt", join: JOINS[s.int(5)] ?? "miter", miter: s.float(7, 10) };
      const dash = f32s(s.bytesOf(6));
      if (dash) stroke.dash = dash;
      const { parts, badOp } = rbPath(s.msg(1) ?? Msg.from(void 0), s.has(2) ? affine(s.msg(2)) : void 0);
      return { kind: "path", parts: parts.map((p) => ({ ...p, stroke: p.stroke ?? stroke })), badOp };
    }
    case 5:
      return {
        kind: "glyphs",
        font: s.msg(1)?.int(1) ?? 0,
        glyphs: s.msgs(2).map((g) => ({ gid: g.int(1), x: g.float(2) }))
      };
    default:
      return { kind: "unknown", field: f.no };
  }
}
function f16Color(raw) {
  if (!raw || raw.length < 8) return [0, 0, 0, 1];
  const dv = new DataView(raw.buffer, raw.byteOffset, 8);
  return [0, 1, 2, 3].map((k) => f16(dv.getUint16(2 * k, true)));
}
function decodeRBPaint(m) {
  const f = m?.fields[0];
  if (!m || !f) return { kind: "color", color: [0, 0, 0, 1] };
  const p = Msg.from(f);
  switch (f.no) {
    case 1: {
      const c = f16Color(p.get(1)?.raw);
      return { kind: "color", color: p.int(2) === 2 ? [lin2srgb(c[0]), lin2srgb(c[1]), lin2srgb(c[2]), c[3]] : c };
    }
    case 2:
      return { kind: "linear", stops: decodeStops(void 0, { colors: p.bytesOf(1), locs: p.bytesOf(2) }), from: pt(p.msg(7)), to: pt(p.msg(8)) };
    case 3: {
      const c = p.msg(4);
      return { kind: "image", resource: p.msg(1)?.int(1) ?? 0, m: affine(p.msg(3)), color: c ? f16Color(c.get(1)?.raw) : void 0 };
    }
    default:
      return { kind: "unknown", field: f.no };
  }
}

// extension/diagnose.ts
import { readdirSync as readdirSync2, readFileSync as readFileSync2 } from "node:fs";
import { homedir, release } from "node:os";
import { join as join2 } from "node:path";
var MIN_DARWIN = 25;
var GROUPS = () => join2(homedir(), "Library/Group Containers");
var problems = {
  notMacos: (platform) => ({
    code: "not-macos",
    title: "Live Activities needs a Mac",
    detail: `This computer runs ${platform}. Only macOS receives your iPhone's Live Activities.`,
    steps: ["Install the bridgething desktop app on a Mac with macOS 26 or later", "Install Live Activities there"]
  }),
  oldMacos: (darwin) => ({
    code: "old-macos",
    title: "This Mac needs macOS 26",
    detail: `iPhone Live Activities on the Mac arrived in macOS 26 Tahoe; this Mac runs macOS ${darwin + 1}.`,
    steps: ["Update the Mac in System Settings > General > Software Update"]
  }),
  // macOS charges file access to the app that launched the extension: the desktop app once installed, but the
  // terminal app during `bun run dev`, which runs the extension from the project's .dev-extension folder
  noFullDiskAccess: () => import.meta.url.includes("/.dev-extension/") ? {
    code: "no-full-disk-access",
    title: "Give your terminal app Full Disk Access",
    detail: "The dev loop runs the extension from your terminal, so macOS asks that app for access, not bridgething.",
    steps: [
      "Open System Settings > Privacy & Security > Full Disk Access",
      "Turn on the app you ran bun run dev in (Terminal, iTerm, VS Code, ...)",
      "Quit that app, reopen it, and start the dev loop again"
    ]
  } : {
    code: "no-full-disk-access",
    title: "Give bridgething Full Disk Access",
    detail: "macOS keeps Live Activities in protected folders that only apps with Full Disk Access can read.",
    steps: [
      "On the Mac, open System Settings > Privacy & Security > Full Disk Access",
      "Turn on bridgething (use + to add it from Applications if it is missing)",
      "Quit and reopen the bridgething desktop app"
    ]
  },
  permission: (what) => ({
    code: "permission",
    title: "Live Activities is missing a permission",
    detail: `The extension was not allowed to ${what}.`,
    steps: ["In the bridgething desktop app, reinstall Live Activities and approve its permissions"]
  }),
  off: () => ({
    code: "live-activities-off",
    title: "iPhone Live Activities are off on this Mac",
    detail: "The Mac is not receiving Live Activities from your iPhone.",
    steps: ['On the Mac, open System Settings and search for "Live Activities"', "Turn on Live Activities from iPhone"]
  }),
  noIphone: () => ({
    code: "no-iphone",
    title: "No iPhone is connected to this Mac",
    detail: "The Mac shows Live Activities from an iPhone signed in to the same Apple Account.",
    steps: [
      "Sign in to the same Apple Account on the iPhone (iOS 26 or later) and the Mac",
      'Keep Bluetooth and Wi-Fi on for both, then search System Settings for "Live Activities"'
    ]
  }),
  neverSynced: () => ({
    code: "never-synced",
    title: "Waiting for a first Live Activity",
    detail: "This Mac has not received any Live Activity from your iPhone yet.",
    steps: ["Start one on the iPhone, for example a timer in an app that shows Live Activities", "It should appear in the Mac menu bar, then here"]
  })
};
var notCapable = (err) => err?.name === "NotCapable";
function diagnose() {
  if (process.platform !== "darwin") return problems.notMacos(process.platform === "win32" ? "Windows" : process.platform);
  try {
    const darwin = parseInt(release(), 10);
    if (darwin && darwin < MIN_DARWIN) return problems.oldMacos(darwin);
  } catch (err) {
    if (notCapable(err)) return problems.permission("read the macOS version");
  }
  try {
    readdirSync2(join2(GROUPS(), "group.com.apple.liveactivitiesd"));
  } catch (err) {
    if (notCapable(err)) return problems.permission("read the Live Activities store");
    const code = err.code;
    if (code === "EPERM" || code === "EACCES") return problems.noFullDiskAccess();
    if (code !== "ENOENT") throw err;
    return settingsProblem() ?? problems.neverSynced();
  }
  return settingsProblem();
}
function settingsProblem() {
  try {
    const prefs = parseBplist(new Uint8Array(readFileSync2(join2(homedir(), "Library/Preferences/com.apple.controlcenter.plist"))));
    if (!prefs || typeof prefs !== "object" || Array.isArray(prefs) || prefs instanceof Uint8Array || prefs instanceof Date) return null;
    if (prefs.RemoteLiveActivitiesEnabled === false) return problems.off();
    const state = prefs.LiveActivityState;
    if (state instanceof Uint8Array) {
      const s = JSON.parse(new TextDecoder().decode(state));
      if (s.Enabled === false || s.SettingEnabled === false) return problems.off();
      if (s.CompanionPaired === false) return problems.noIphone();
    }
  } catch {
  }
  return null;
}
function problemFromError(err) {
  if (notCapable(err)) return problems.permission("read the Live Activities store");
  return diagnose() ?? problems.noFullDiskAccess();
}

// extension/source.ts
import { DatabaseSync } from "node:sqlite";
import { existsSync, readdirSync as readdirSync3, statSync, watch } from "node:fs";
import { homedir as homedir2 } from "node:os";
import { join as join3 } from "node:path";
var GROUPS2 = join3(homedir2(), "Library/Group Containers");
var DB_PATH = join3(GROUPS2, "group.com.apple.liveactivitiesd/liveactivitiesd.sql");
var ARCHIVES = join3(GROUPS2, "group.com.apple.chronod/chronod/remoteArchives");
var utf8 = new TextDecoder();
var APPLE_EPOCH_MS = 9783072e5;
var appleDate = (s) => s == null ? null : APPLE_EPOCH_MS + s * 1e3;
function decodeJsonish(value, depth = 0) {
  if (depth > 4) return value;
  if (typeof value === "string") {
    const t = value.trim();
    if (t.startsWith("{") && t.endsWith("}") || t.startsWith("[") && t.endsWith("]")) {
      try {
        return decodeJsonish(JSON.parse(t), depth + 1);
      } catch {
      }
    }
    return value;
  }
  if (Array.isArray(value)) return value.map((v) => decodeJsonish(v, depth + 1));
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, decodeJsonish(v, depth + 1)]));
  }
  return value;
}
function decodeBase64Json(b64) {
  if (typeof b64 !== "string" || !b64) return null;
  try {
    return decodeJsonish(utf8.decode(Uint8Array.from(atob(b64), (c) => c.charCodeAt(0))));
  } catch {
    return null;
  }
}
function findArchive(deviceId, bundleId, activityId) {
  if (!deviceId) return null;
  const dir = join3(ARCHIVES, deviceId, bundleId, "com.apple.chrono/activities");
  if (!existsSync(dir)) return null;
  let best = null;
  for (const name of readdirSync3(dir)) {
    if (!name.startsWith(activityId) || !name.endsWith(".activity-archive")) continue;
    const path = join3(dir, name);
    const mtime = statSync(path).mtimeMs;
    if (!best || mtime > best.mtime) best = { path, mtime };
  }
  return best;
}
function readActivities() {
  const db = new DatabaseSync(DB_PATH, { readOnly: true });
  try {
    const rows = db.prepare(
      `select activityIdentifier, deviceIdentifier, requester, localizedAppName, startDate, request, payload
         from Activities where dismissalDate is null order by startDate`
    ).all();
    return rows.map((row) => {
      const request2 = JSON.parse(utf8.decode(row.request));
      const payload = JSON.parse(utf8.decode(row.payload));
      const content = payload.content ?? payload;
      const archive = findArchive(row.deviceIdentifier, row.requester, row.activityIdentifier);
      return {
        id: row.activityIdentifier,
        bundleId: row.requester,
        appName: row.localizedAppName ?? row.requester,
        deviceId: row.deviceIdentifier,
        attributesType: request2.attributesType?.attributesType ?? null,
        startedAt: appleDate(row.startDate),
        updatedAt: appleDate(payload.timestamp),
        staleAt: appleDate(content.staleDate),
        relevance: content.relevanceScore ?? 0,
        attributes: decodeBase64Json(request2.attributesData),
        content: decodeBase64Json(content.contentState),
        archivePath: archive?.path ?? null,
        archiveMtime: archive?.mtime ?? 0
      };
    });
  } finally {
    db.close();
  }
}
function watchActivities(onChange, { debounceMs = 120, pollMs = 1e4 } = {}) {
  let timer = null;
  const kick = () => {
    if (timer) clearTimeout(timer);
    timer = setTimeout(onChange, debounceMs);
  };
  const watchers = [];
  const dbDir = join3(DB_PATH, "..");
  watchers.push(watch(dbDir, (_e, name) => name?.startsWith("liveactivitiesd.sql") && kick()));
  if (existsSync(ARCHIVES)) {
    watchers.push(watch(ARCHIVES, { recursive: true }, (_e, name) => name?.endsWith(".activity-archive") && kick()));
  }
  const poll = setInterval(onChange, pollMs);
  return () => {
    watchers.forEach((w) => w.close());
    clearInterval(poll);
    if (timer) clearTimeout(timer);
  };
}

// extension/switcher.ts
var import_msgpack = __toESM(require_dist(), 1);
import { lookup } from "node:dns/promises";
import { networkInterfaces } from "node:os";
var PORT = 8892;
var TIMEOUT_MS = 3e3;
var uuidBytes = (s) => Uint8Array.from(s.replace(/-/g, "").match(/../g), (h) => parseInt(h, 16));
var hexOf = (b) => Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
function frame(message) {
  const body = (0, import_msgpack.encode)(message);
  const out = new Uint8Array(new ArrayBuffer(16 + body.length));
  const view = new DataView(out.buffer);
  view.setUint16(0, 57005);
  view.setUint8(2, 2);
  view.setBigUint64(8, BigInt(body.length));
  out.set(body, 16);
  return out;
}
function request(host, data) {
  return new Promise((resolve) => {
    const id = crypto.getRandomValues(new Uint8Array(16));
    let ws;
    try {
      ws = new WebSocket(`ws://${host}:${PORT}/`);
    } catch {
      return resolve(null);
    }
    ws.binaryType = "arraybuffer";
    const done = (v) => {
      clearTimeout(timer);
      try {
        ws.close();
      } catch {
      }
      resolve(v);
    };
    const timer = setTimeout(() => done(null), TIMEOUT_MS);
    ws.onerror = () => done(null);
    ws.onopen = () => ws.send(frame({ id, meta: { kind: "request" }, data }));
    ws.onmessage = (ev) => {
      const buf = new Uint8Array(ev.data);
      if (buf.length < 16 || new DataView(buf.buffer).getUint16(0) !== 57005) return;
      try {
        const msg = (0, import_msgpack.decode)(buf.subarray(16));
        if (msg?.meta?.kind === "response" && hexOf(msg.meta.data.requestId) === hexOf(id)) done(msg.data);
      } catch {
      }
    };
  });
}
async function candidates() {
  const hosts = /* @__PURE__ */ new Set();
  const mdns = await lookup("bridgething.local", { family: 4 }).catch(() => null);
  if (mdns) hosts.add(mdns.address);
  let ifaces = {};
  try {
    ifaces = networkInterfaces();
  } catch {
  }
  for (const addrs of Object.values(ifaces)) {
    for (const a of addrs ?? []) {
      if (a.family !== "IPv4" || !a.address.startsWith("10.42.")) continue;
      const parts = a.address.split(".").map(Number);
      const base = parts[3] & ~7;
      for (let i = 1; i < 7; i++) if (base + i !== parts[3]) hosts.add(`${parts[0]}.${parts[1]}.${parts[2]}.${base + i}`);
    }
  }
  return [...hosts];
}
async function activeOn(host) {
  const r = await request(host, { type: "webapp", data: { event: "getActive" } });
  if (r?.type !== "webapp" || r.data?.event !== "active") return void 0;
  return r.data.data?.id ?? null;
}
var switchTo = async (host, id) => (await request(host, { type: "webapp", data: { event: "switchTo", data: { id } } }))?.data?.event === "switched";
var previous = /* @__PURE__ */ new Map();
async function bringForward(webappId) {
  const id = uuidBytes(webappId);
  let switched = 0;
  await Promise.all(
    (await candidates()).map(async (host) => {
      const current = await activeOn(host);
      if (current === void 0 || current && hexOf(current) === hexOf(id)) return;
      if (await switchTo(host, id)) {
        if (current) previous.set(host, current);
        switched++;
      }
    })
  );
  return switched;
}
async function restore(webappId) {
  const want = hexOf(uuidBytes(webappId));
  await Promise.all(
    [...previous].map(async ([host, prev]) => {
      const current = await activeOn(host);
      if (current && hexOf(current) === want) await switchTo(host, prev);
    })
  );
  previous.clear();
}

// extension/main.ts
var VIEW_TAGS = {
  listItem: "listItem",
  expanded: "dynamicIsland-expanded",
  compactLeading: "dynamicIsland-compactLeading",
  compactTrailing: "dynamicIsland-compactTrailing",
  minimal: "dynamicIsland-compactMinimal"
};
var ARCHIVE_GRACE_MS = 8e3;
var HEARTBEAT_MS = 5e3;
var RECHECK_MS = 1e4;
var revOf = (a) => `${a.archivePath}:${a.archiveMtime}:${a.updatedAt}`;
async function render(a) {
  const out = { rev: revOf(a), views: {}, texts: [] };
  if (!a.archivePath) return out;
  const { readFile } = await import("node:fs/promises");
  const archive = readArchive(new Uint8Array(await readFile(a.archivePath)));
  for (const [key, viewTag] of Object.entries(VIEW_TAGS)) {
    const v = renderView(archive, { viewTag, colorScheme: "dark", luminanceReduced: false, redaction: 0 });
    if (!v) continue;
    out.views[key] = { svg: v.svg, width: v.width, height: v.height, cornerRadius: v.cornerRadius, tint: v.backgroundTint ?? null };
    if (key === "listItem" || !out.texts.length) out.texts = v.texts;
  }
  return out;
}
var icons = /* @__PURE__ */ new Map();
async function iconFor(bundleId) {
  if (icons.has(bundleId)) return;
  icons.set(bundleId, null);
  try {
    const r = await fetch(`https://itunes.apple.com/lookup?bundleId=${encodeURIComponent(bundleId)}`);
    const art = (await r.json()).results?.[0]?.artworkUrl512;
    if (!art) return;
    const img = await fetch(art.replace(/\/\d+x\d+bb\./, "/192x192bb."));
    const bytes = new Uint8Array(await img.arrayBuffer());
    let bin = "";
    for (let i = 0; i < bytes.length; i += 32768) bin += String.fromCharCode(...bytes.subarray(i, i + 32768));
    icons.set(bundleId, `data:${img.headers.get("content-type") ?? "image/jpeg"};base64,${btoa(bin)}`);
  } catch {
  }
}
function start(ctx) {
  let shown = [];
  const rendered = /* @__PURE__ */ new Map();
  const firstSeen = /* @__PURE__ */ new Map();
  let tookOver = false;
  let problem = null;
  const setProblem = (next) => {
    if (next?.code === problem?.code) return;
    problem = next;
    if (next) ctx.log.error(`${next.title}. ${next.detail} ${next.steps.join("; ")}.`);
    else ctx.log.info("live activity stores are readable");
    ctx.broadcast(snapshot("all"));
  };
  const ready = (a) => {
    const v = rendered.get(a.id)?.views;
    return !!(v?.listItem || v?.expanded) || Date.now() - (firstSeen.get(a.id) ?? Date.now()) >= ARCHIVE_GRACE_MS;
  };
  const focusOn = (trigger) => ctx.devices.some((d) => {
    if (!d.connected) return false;
    const mode = ctx.config(d).bring_to_front ?? "When one starts";
    return mode === "When one starts or updates" || mode === "When one starts" && trigger === "start";
  });
  const lastTexts = /* @__PURE__ */ new Map();
  const snapshot = (withViews) => {
    const full = (id) => withViews === "all" || withViews.has(id);
    return json({
      type: "snapshot",
      at: Date.now(),
      problem,
      icons: Object.fromEntries(
        shown.filter((a) => full(a.id) && icons.get(a.bundleId)).map((a) => [a.bundleId, icons.get(a.bundleId)])
      ),
      activities: shown.map((a) => {
        const r = rendered.get(a.id);
        return {
          id: a.id,
          bundleId: a.bundleId,
          appName: a.appName,
          startedAt: a.startedAt,
          updatedAt: a.updatedAt,
          staleAt: a.staleAt,
          content: a.content,
          texts: r.texts,
          rev: r.rev,
          ...full(a.id) ? { views: r.views } : {}
        };
      })
    });
  };
  let running = false;
  let again = false;
  const refresh = async () => {
    if (running) return void (again = true);
    running = true;
    try {
      const next = readActivities();
      if (problem) setProblem(null);
      const before = new Set(shown.map((a) => a.id));
      const changed = /* @__PURE__ */ new Set();
      for (const a of next) {
        if (!firstSeen.has(a.id)) {
          firstSeen.set(a.id, Date.now());
          setTimeout(() => void refresh(), ARCHIVE_GRACE_MS + 50);
        }
        if (rendered.get(a.id)?.rev === revOf(a)) continue;
        try {
          rendered.set(a.id, await render(a));
        } catch (err) {
          ctx.log.warn(`could not decode ${a.appName}'s archive: ${err.message}`);
          rendered.set(a.id, { rev: revOf(a), views: {}, texts: [] });
        }
        await iconFor(a.bundleId);
        changed.add(a.id);
      }
      const live = new Set(next.map((a) => a.id));
      for (const id of [...rendered.keys()]) if (!live.has(id)) rendered.delete(id), firstSeen.delete(id);
      const nowShown = next.filter(ready);
      const started = nowShown.filter((a) => !before.has(a.id));
      for (const a of started) changed.add(a.id);
      const removed = shown.some((a) => !live.has(a.id) || !nowShown.some((b) => b.id === a.id));
      const ended = shown.length > 0 && nowShown.length === 0;
      shown = nowShown;
      for (const a of started) ctx.log.info(`+ ${a.appName}`);
      if (changed.size || removed) ctx.broadcast(snapshot(changed));
      const updated = nowShown.some((a) => {
        const said = rendered.get(a.id).texts.join("\n");
        const before2 = lastTexts.get(a.id);
        lastTexts.set(a.id, said);
        return before2 !== void 0 && before2 !== said;
      });
      for (const id of [...lastTexts.keys()]) if (!live.has(id)) lastTexts.delete(id);
      const trigger = started.length ? "start" : updated ? "update" : null;
      if (trigger && focusOn(trigger)) tookOver = await bringForward(ctx.webapp.id) > 0 || tookOver;
      if (ended && tookOver) await restore(ctx.webapp.id), tookOver = false;
    } catch (err) {
      setProblem(problemFromError(err));
    } finally {
      running = false;
      if (again) again = false, void refresh();
    }
  };
  const sendAll = (device) => device.active && device.send(snapshot("all"));
  ctx.on("device", (event) => {
    if (event.type === "connected" || event.type === "active") sendAll(event.device);
  });
  ctx.on("message", (device, message) => {
    if (asJson(message)?.type === "hello") sendAll(device);
  });
  const heartbeat = setInterval(() => ctx.broadcast(snapshot(/* @__PURE__ */ new Set())), HEARTBEAT_MS);
  let stopWatching;
  const tryStart = () => {
    let found;
    try {
      found = diagnose();
    } catch (err) {
      found = problemFromError(err);
    }
    if (found && found.code !== "never-synced") return setProblem(found);
    setProblem(found);
    if (stopWatching) return void refresh();
    try {
      stopWatching = watchActivities(() => void refresh());
    } catch (err) {
      return setProblem(problemFromError(err));
    }
    void refresh();
  };
  tryStart();
  const recheck = setInterval(() => (problem || !stopWatching) && tryStart(), RECHECK_MS);
  return () => {
    stopWatching?.();
    clearInterval(heartbeat);
    clearInterval(recheck);
  };
}
var stop;
defineExtension({
  start(ctx) {
    stop = start(ctx);
  },
  stop() {
    stop?.();
  }
});
